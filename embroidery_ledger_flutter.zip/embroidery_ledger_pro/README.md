# Embroidery Ledger — Flutter

Flutter port of the original single-file HTML app (worker payroll + khata
ledger for an embroidery business). Firebase (Google sign-in + Firestore
sync) is wired in, matching the original web app's sharing feature.

## Structure

```
lib/
  models/          Worker, ShiftEntry, Payment, MonthMeta, Account,
                    KhataTransaction, CashEntry, AppSettings
  state/
    app_state.dart  Central ChangeNotifier — mirrors the web app's global
                     `state` object + all derived-stat functions
                     (getMonthStats, getWorkerAllTimeStats, getKhataBalance)
  services/
    local_storage_service.dart   SharedPreferences cache (localStorage equiv.)
    auth_service.dart            Firebase Auth + Google Sign-In
    firestore_service.dart       Shared-worker sync (Firestore)
    pdf_service.dart             Khata statement PDF export/share
  screens/
    root_shell.dart              Bottom-nav shell, 4 tabs, per-tab back stack
    workers/                     Workers tab: list, profile, month detail,
                                  day-entry sheet, salary-payment sheet
    payments/                    Payments tab: all-worker payment history
    cash/                        Cash tab: income/expense book
    khata/                       Khata tab: accounts list, account detail,
                                  add account/transaction sheets
    settings/                    Theme, language, sign-in/out
  utils/
    app_theme.dart   Light/dark palettes ported from the CSS custom properties
  firebase_options.dart   Placeholder — replace via `flutterfire configure`
  main.dart
```

## Setup

1. **Install dependencies**
   ```
   flutter pub get
   ```

2. **Configure Firebase** (required — the placeholder Android/iOS keys in
   `lib/firebase_options.dart` won't work):
   ```
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   This connects to the existing `webapp-9504b` Firebase project (or a new
   one) and regenerates `firebase_options.dart` with real, platform-specific
   keys. The web config values already in the placeholder file match the
   original app's `firebaseConfig`.

3. **Enable Google Sign-In** in the Firebase console (Authentication →
   Sign-in method) if not already on, and add your app's SHA-1 fingerprint
   for Android.

4. **Firestore rules** — the app writes to `sharedLedgers/{email}`. Add
   rules restricting reads to the signed-in user matching that email.

5. **Run**
   ```
   flutter run
   ```

## What's ported

- Workers: list with drag-reorder, profile, monthly stats, daily shift
  entries (stitches/rate/hours/advance/absent), salary & advance payments,
  the opening-balance carry-forward logic when a month is "settled".
- Cash book: income/expense entries with running totals.
- Khata: customer/supplier accounts, bill/payment transactions, running
  balance, PDF statement export & native share.
- Settings: theme, language, Google sign-in/out.

## Not yet ported (present in the original but out of scope for this pass)

- Month "settle/carry forward" UI action and the account-sharing
  invite/accept flow (data model + Firestore sync helpers are in place;
  the specific settle-month and share-management dialogs still need
  screens).
- Category management UI (add/hide custom categories) — the state layer
  supports it (`getCategories()`, `addTxCategory()`), but there's no
  dedicated settings screen for editing them yet.
- Worker photo capture/crop.
- CSV/Drive backup.

These are natural next additions once you've reviewed this structure.
