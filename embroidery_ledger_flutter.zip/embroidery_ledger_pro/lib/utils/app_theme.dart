import 'package:flutter/material.dart';

/// Mirrors the :root / [data-theme="dark"] CSS custom properties from the web app.
class AppColors {
  final Color bg;
  final Color bgElevated;
  final Color bgSoft;
  final Color bgInput;
  final Color text;
  final Color textDim;
  final Color textFaint;
  final Color accent;
  final Color accent2;
  final Color accentSoft;
  final Color amber;
  final Color amberSoft;
  final Color red;
  final Color red2;
  final Color redSoft;
  final Color blue;
  final Color blueSoft;
  final Color green;
  final Color border;
  final List<BoxShadow> shadowSm;
  final List<BoxShadow> shadow;
  final List<BoxShadow> shadowLg;

  const AppColors({
    required this.bg,
    required this.bgElevated,
    required this.bgSoft,
    required this.bgInput,
    required this.text,
    required this.textDim,
    required this.textFaint,
    required this.accent,
    required this.accent2,
    required this.accentSoft,
    required this.amber,
    required this.amberSoft,
    required this.red,
    required this.red2,
    required this.redSoft,
    required this.blue,
    required this.blueSoft,
    required this.green,
    required this.border,
    required this.shadowSm,
    required this.shadow,
    required this.shadowLg,
  });

  /// linear-gradient(135deg, accent, accent2) — used by .hero-card
  LinearGradient get accentGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [accent, accent2],
      );

  LinearGradient get redGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [red, red2],
      );

  static const light = AppColors(
    bg: Color(0xFFF2F5FA),
    bgElevated: Color(0xFFFFFFFF),
    bgSoft: Color(0xFFE8EEF9),
    bgInput: Color(0xFFEEF2F9),
    text: Color(0xFF101623),
    textDim: Color(0xFF5A6478),
    textFaint: Color(0xFF8A93A6),
    accent: Color(0xFF2563EB),
    accent2: Color(0xFF3B82F6),
    accentSoft: Color(0xFFDBE7FD),
    amber: Color(0xFFB36B22),
    amberSoft: Color(0xFFF6E8D5),
    red: Color(0xFFDC2626),
    red2: Color(0xFFEF4444),
    redSoft: Color(0xFFFBDCDA),
    blue: Color(0xFF1D4ED8),
    blueSoft: Color(0xFFDCE7FC),
    green: Color(0xFF16A34A),
    border: Color(0xFFD7E0EE),
    shadowSm: [BoxShadow(color: Color(0x12101E3C), blurRadius: 3, offset: Offset(0, 1))],
    shadow: [BoxShadow(color: Color(0x17101E3C), blurRadius: 20, offset: Offset(0, 4))],
    shadowLg: [BoxShadow(color: Color(0x24101E3C), blurRadius: 30, offset: Offset(0, 8))],
  );

  static const dark = AppColors(
    bg: Color(0xFF000000),
    bgElevated: Color(0xFF0C0C0E),
    bgSoft: Color(0xFF151517),
    bgInput: Color(0xFF121214),
    text: Color(0xFFFFFFFF),
    textDim: Color(0xFFABABAB),
    textFaint: Color(0xFF6E6E6E),
    accent: Color(0xFF4C8DFF),
    accent2: Color(0xFF7FB0FF),
    accentSoft: Color(0x294C8DFF),
    amber: Color(0xFFFFB020),
    amberSoft: Color(0x24FFB020),
    red: Color(0xFFF06050),
    red2: Color(0xFFFF7060),
    redSoft: Color(0x29F06050),
    blue: Color(0xFF4C8DFF),
    blueSoft: Color(0x294C8DFF),
    green: Color(0xFF22C55E),
    border: Color(0xFF232326),
    shadowSm: [BoxShadow(color: Color(0x99000000), blurRadius: 3, offset: Offset(0, 1))],
    shadow: [BoxShadow(color: Color(0xB3000000), blurRadius: 18, offset: Offset(0, 4))],
    shadowLg: [BoxShadow(color: Color(0xCC000000), blurRadius: 36, offset: Offset(0, 10))],
  );
}

class AppTheme {
  static ThemeData build(AppColors c, Brightness brightness) {
    return ThemeData(
      brightness: brightness,
      scaffoldBackgroundColor: c.bg,
      fontFamily: 'Roboto',
      colorScheme: ColorScheme.fromSeed(
        seedColor: c.accent,
        brightness: brightness,
        primary: c.accent,
        surface: c.bgElevated,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: c.bg,
        foregroundColor: c.text,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(
          color: c.text,
          fontWeight: FontWeight.w800,
          fontSize: 18,
          letterSpacing: -0.2,
        ),
      ),
      cardColor: c.bgElevated,
      dividerColor: c.border,
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: c.bgInput,
        contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: c.border, width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: c.border, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: c.accent, width: 1.5),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: c.accent,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: c.text,
          side: BorderSide(color: c.border, width: 1.5),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: c.bgElevated,
        selectedItemColor: c.accent,
        unselectedItemColor: c.textFaint,
      ),
      useMaterial3: true,
    );
  }
}

/// Helper to grab the active [AppColors] anywhere via Theme.of(context).extension,
/// without wiring a full ThemeExtension — screens just do `appColors(context)`.
class AppColorsProvider extends InheritedWidget {
  final AppColors colors;
  const AppColorsProvider({super.key, required this.colors, required super.child});

  static AppColors of(BuildContext context) {
    final w = context.dependOnInheritedWidgetOfExactType<AppColorsProvider>();
    return w?.colors ?? AppColors.dark;
  }

  @override
  bool updateShouldNotify(AppColorsProvider oldWidget) => oldWidget.colors != colors;
}

AppColors appColors(BuildContext context) => AppColorsProvider.of(context);
