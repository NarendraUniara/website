import 'package:intl/intl.dart';

/// Mirrors money(n) in the web app: ₹ prefix, Indian digit grouping,
/// no decimals for whole numbers, up to 2 decimals otherwise, '-' for negatives.
String money(num? n) {
  final v = n ?? 0;
  final neg = v < -0.001;
  final abs = v.abs();
  final isWhole = (abs % 1) == 0;
  final fmt = NumberFormat.currency(
    locale: 'en_IN',
    symbol: '₹',
    decimalDigits: isWhole ? 0 : 2,
  );
  final str = fmt.format(abs);
  return neg ? '-$str' : str;
}

/// Indian-style digit grouping without a currency symbol (mirrors
/// Number(x).toLocaleString('en-IN') used for stitch counts etc).
String numberIN(num? n) {
  final v = n ?? 0;
  final isWhole = (v % 1) == 0;
  return NumberFormat.decimalPattern('en_IN').format(isWhole ? v.toInt() : v);
}

const List<String> monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const List<String> monthAbbr = [
  'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
  'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC',
];

/// NOTE: unlike the web app's JS (month 0-11), this Flutter port uses
/// month 1-12 throughout (matching Dart's own DateTime convention), so
/// these helpers index accordingly.
String monthLabel(int year, int month) => '${monthNames[month - 1]} $year';

String monthAbbrOf(int month) => monthAbbr[month - 1];

int daysInMonth(int year, int month) => DateTime(year, month + 1, 0).day;

({int year, int month}) nextMonthOf(int year, int month) {
  var m = month + 1;
  var y = year;
  if (m > 12) {
    m = 1;
    y++;
  }
  return (year: y, month: m);
}

/// Mirrors initials(name) in the web app.
String initials(String? name) {
  final parts = (name ?? '?').trim().split(RegExp(r'\s+'));
  final first = parts.isNotEmpty ? parts[0] : '';
  final second = parts.length > 1 ? parts[1] : '';
  final a = first.isNotEmpty ? first[0] : '';
  final b = second.isNotEmpty ? second[0] : (first.length > 1 ? first[1] : '');
  return (a + b).toUpperCase();
}
