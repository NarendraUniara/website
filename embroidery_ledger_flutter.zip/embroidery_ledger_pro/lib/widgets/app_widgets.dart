import 'dart:convert';

import 'package:flutter/material.dart';

import '../utils/app_theme.dart';
import '../utils/format.dart';

/// Mirrors .card
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry margin;

  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(15),
    this.onTap,
    this.margin = const EdgeInsets.only(bottom: 10),
  });

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    final card = Container(
      margin: margin,
      decoration: BoxDecoration(
        color: c.bgElevated,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: c.border, width: 1.2),
        boxShadow: c.shadowSm,
      ),
      child: Padding(padding: padding, child: child),
    );
    if (onTap == null) return card;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: card,
    );
  }
}

/// Mirrors .hero-card — gradient amount card used in dashboards.
class HeroCard extends StatelessWidget {
  final String label;
  final String amount;
  final bool isRed;
  final bool compact;

  const HeroCard({
    super.key,
    required this.label,
    required this.amount,
    this.isRed = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 14, vertical: compact ? 13 : 16),
      decoration: BoxDecoration(
        gradient: isRed ? c.redGradient : c.accentGradient,
        borderRadius: BorderRadius.circular(14),
        boxShadow: c.shadowLg,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label.toUpperCase(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10.5,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.6,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            amount,
            style: TextStyle(
              color: Colors.white,
              fontSize: compact ? 18 : 26,
              fontWeight: FontWeight.w800,
              letterSpacing: -0.5,
            ),
          ),
        ],
      ),
    );
  }
}

/// A row of [HeroCard]s with equal flex — mirrors .hero-row
class HeroRow extends StatelessWidget {
  final List<HeroCard> cards;
  const HeroRow({super.key, required this.cards});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        for (var i = 0; i < cards.length; i++) ...[
          if (i > 0) const SizedBox(width: 8),
          Expanded(child: cards[i]),
        ],
      ],
    );
  }
}

enum BadgeTone { neutral, green, amber, red, blue }

/// Mirrors .badge / .badge.green / .badge.amber / .badge.blue
class StatusBadge extends StatelessWidget {
  final String text;
  final BadgeTone tone;
  const StatusBadge(this.text, {super.key, this.tone = BadgeTone.neutral});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    Color bg;
    Color fg;
    switch (tone) {
      case BadgeTone.green:
        bg = c.green.withOpacity(0.16);
        fg = c.green;
        break;
      case BadgeTone.amber:
        bg = c.amberSoft;
        fg = c.amber;
        break;
      case BadgeTone.red:
        bg = c.redSoft;
        fg = c.red;
        break;
      case BadgeTone.blue:
        bg = c.blueSoft;
        fg = c.blue;
        break;
      case BadgeTone.neutral:
        bg = c.bgSoft;
        fg = c.textDim;
        break;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(
        text,
        style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w700),
      ),
    );
  }
}

/// Mirrors .section-head — title/sub on the left, optional + button on the right.
class SectionHead extends StatelessWidget {
  final String title;
  final String? subtitle;
  final VoidCallback? onAdd;

  const SectionHead({super.key, required this.title, this.subtitle, this.onAdd});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 9),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w800, color: c.text, letterSpacing: -0.1)),
                if (subtitle != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(subtitle!, style: TextStyle(fontSize: 12, color: c.textFaint, fontWeight: FontWeight.w500)),
                  ),
              ],
            ),
          ),
          if (onAdd != null) HeadPlusButton(onTap: onAdd!),
        ],
      ),
    );
  }
}

/// Mirrors .head-plus — small circular accent-filled + button.
class HeadPlusButton extends StatelessWidget {
  final VoidCallback onTap;
  final IconData icon;
  final bool secondary;
  const HeadPlusButton({super.key, required this.onTap, this.icon = Icons.add, this.secondary = false});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: secondary ? c.bgElevated : c.accent,
          borderRadius: BorderRadius.circular(10),
          border: secondary ? Border.all(color: c.border, width: 1.5) : null,
        ),
        child: Icon(icon, color: secondary ? c.text : Colors.white, size: 19),
      ),
    );
  }
}

/// Mirrors .avatar — initials circle or photo.
class AppAvatar extends StatelessWidget {
  final String name;
  final String? photoUrl;
  final double size;

  const AppAvatar({super.key, required this.name, this.photoUrl, this.size = 44});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    Widget image = _initialsText(c);
    if (photoUrl != null && photoUrl!.isNotEmpty) {
      if (photoUrl!.startsWith('data:')) {
        try {
          final b64 = photoUrl!.substring(photoUrl!.indexOf(',') + 1);
          image = Image.memory(base64Decode(b64), fit: BoxFit.cover, width: size, height: size,
              errorBuilder: (_, __, ___) => _initialsText(c));
        } catch (_) {
          image = _initialsText(c);
        }
      } else {
        image = Image.network(photoUrl!, fit: BoxFit.cover, width: size, height: size,
            errorBuilder: (_, __, ___) => _initialsText(c));
      }
    }
    return ClipOval(
      child: Container(
        width: size,
        height: size,
        color: c.accentSoft,
        alignment: Alignment.center,
        child: image,
      ),
    );
  }

  Widget _initialsText(AppColors c) => Text(
        initials(name),
        style: TextStyle(color: c.accent, fontWeight: FontWeight.w800, fontSize: size * 0.34),
      );
}

/// Mirrors .worker-row / .card.clickable list rows with avatar + info + chevron.
class ListRowCard extends StatelessWidget {
  final Widget leading;
  final String title;
  final String subtitle;
  final List<Widget> badges;
  final VoidCallback onTap;

  const ListRowCard({
    super.key,
    required this.leading,
    required this.title,
    required this.subtitle,
    this.badges = const [],
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return AppCard(
      onTap: onTap,
      child: Row(
        children: [
          leading,
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: c.text)),
                const SizedBox(height: 2),
                Text(subtitle, style: TextStyle(fontSize: 12.5, color: c.textDim, fontWeight: FontWeight.w500)),
                if (badges.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Wrap(spacing: 6, runSpacing: 6, children: badges),
                ],
              ],
            ),
          ),
          Icon(Icons.chevron_right, color: c.textFaint),
        ],
      ),
    );
  }
}

/// Mirrors .stat-grid — a 2-column grid of label/value stat cells.
class StatGrid extends StatelessWidget {
  final List<StatCell> cells;
  const StatGrid({super.key, required this.cells});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 2.6,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      children: cells,
    );
  }
}

class StatCell extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;
  const StatCell({super.key, required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(label, style: TextStyle(fontSize: 11.5, color: c.textFaint, fontWeight: FontWeight.w600)),
        const SizedBox(height: 3),
        Text(value,
            style: TextStyle(
                fontSize: 15.5, fontWeight: FontWeight.w800, color: valueColor ?? c.text, letterSpacing: -0.2)),
      ],
    );
  }
}

/// Mirrors .empty — centered icon + title + subtitle placeholder.
class EmptyState extends StatelessWidget {
  final String emoji;
  final String title;
  final String subtitle;
  const EmptyState({super.key, required this.emoji, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 48),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 40)),
          const SizedBox(height: 10),
          Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: c.text)),
          const SizedBox(height: 4),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12.5, color: c.textFaint, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

/// Mirrors .topbar (plain, no back button) — big page title + subtitle.
class TopbarTitle extends StatelessWidget {
  final String title;
  final String subtitle;
  const TopbarTitle({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: c.text, letterSpacing: -0.4)),
        Text(subtitle, style: TextStyle(fontSize: 12.5, color: c.textDim, fontWeight: FontWeight.w500)),
      ],
    );
  }
}
