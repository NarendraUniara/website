import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/auth_service.dart';
import '../../services/drive_backup_service.dart';
import '../../services/local_backup_service.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../widgets/app_widgets.dart';

/// Mirrors viewSettings(): account (sign-in) + Drive backup, appearance
/// (theme + language toggles), local backup export/restore, and an
/// "Embroidery Ledger · v1.0" footer.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _drive = DriveBackupService();
  final _localBackup = LocalBackupService();
  bool _busy = false;

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _runBusy(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _backupToDrive(AppState appState, AuthService auth) async {
    await _runBusy(() async {
      try {
        final token = await auth.getDriveAccessToken();
        if (token == null) {
          _toast('Drive access nahi mila, dobara try karein');
          return;
        }
        await _drive.backupToDrive(token, appState.toBackupJson());
        appState.settings.driveLastBackup = DateTime.now().millisecondsSinceEpoch;
        appState.scheduleSave();
        _toast('Drive backup ho gaya ✓');
      } catch (e) {
        _toast('Drive backup fail hua: $e');
      }
    });
  }

  Future<void> _restoreFromDrive(AppState appState, AuthService auth) async {
    await _runBusy(() async {
      try {
        final token = await auth.getDriveAccessToken();
        if (token == null) {
          _toast('Drive access nahi mila, dobara try karein');
          return;
        }
        final file = await _drive.findBackupFile(token);
        if (file == null) {
          _toast('Drive par koi backup nahi mila');
          return;
        }
        final parsed = await _drive.downloadBackup(token, file.id);
        if (!mounted) return;
        final confirmed = await _confirmRestore();
        if (confirmed == true) {
          appState.restoreFromBackup(parsed);
          _toast('Drive se restore ho gaya');
        }
      } catch (e) {
        _toast('Drive restore fail hua: $e');
      }
    });
  }

  Future<bool?> _confirmRestore() {
    return showDialog<bool>(
      context: context,
      builder: (dctx) => AlertDialog(
        title: const Text('Backup Restore Karein?'),
        content: const Text(
            'Aapka current data (sab workers, entries, payments) permanently overwrite ho jayega. Photos is device par jaisi hain waisi hi rahengi. Ye undo nahi ho sakta.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dctx).pop(false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(dctx).pop(true), child: const Text('Restore Karein')),
        ],
      ),
    );
  }

  Future<void> _exportLocalBackup(AppState appState) async {
    await _runBusy(() async {
      try {
        await _localBackup.exportBackup(appState.toBackupJson());
      } catch (e) {
        _toast('Backup export fail hua: $e');
      }
    });
  }

  Future<void> _restoreLocalBackup(AppState appState) async {
    await _runBusy(() async {
      try {
        final parsed = await _localBackup.pickAndParseBackup();
        if (parsed == null) return;
        if (!mounted) return;
        final confirmed = await _confirmRestore();
        if (confirmed == true) {
          appState.restoreFromBackup(parsed);
          _toast('Backup restore ho gaya');
        }
      } catch (_) {
        _toast('Invalid backup file');
      }
    });
  }

  String _formatLastBackup(int? epochMs) {
    if (epochMs == null) return 'Abhi tak backup nahi hua';
    final d = DateTime.fromMillisecondsSinceEpoch(epochMs);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    final hour = d.hour % 12 == 0 ? 12 : d.hour % 12;
    final ampm = d.hour >= 12 ? 'PM' : 'AM';
    return '${d.day} ${months[d.month - 1]}, $hour:${d.minute.toString().padLeft(2, '0')} $ampm';
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final auth = context.read<AuthService>();
    final c = appColors(context);
    final user = auth.currentUser;

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: AbsorbPointer(
        absorbing: _busy,
        child: Opacity(
          opacity: _busy ? 0.6 : 1,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              const SectionHead(title: 'Account'),
              AppCard(
                child: user != null
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundImage: user.photoURL != null ? NetworkImage(user.photoURL!) : null,
                                child: user.photoURL == null ? const Icon(Icons.person) : null,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(user.displayName ?? user.email ?? 'Signed in',
                                        style: TextStyle(fontWeight: FontWeight.w700, color: c.text)),
                                    Text(user.email ?? '', style: TextStyle(fontSize: 12, color: c.textDim)),
                                  ],
                                ),
                              ),
                              TextButton(onPressed: () => auth.signOut(), child: const Text('Sign Out')),
                            ],
                          ),
                          Divider(color: c.border, height: 24),
                          const StatusBadge('Google Drive Connected', tone: BadgeTone.green),
                          const SizedBox(height: 10),
                          SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('Auto Drive Backup'),
                            subtitle: const Text('Har badlav ke baad Drive par backup ho jayega'),
                            value: appState.settings.autoDriveBackup,
                            onChanged: (v) {
                              appState.settings.autoDriveBackup = v;
                              appState.scheduleSave();
                            },
                          ),
                          const SizedBox(height: 6),
                          ElevatedButton.icon(
                            icon: const Icon(Icons.cloud_upload_outlined, size: 17),
                            label: const Text('Backup to Drive'),
                            onPressed: () => _backupToDrive(appState, auth),
                          ),
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            icon: const Icon(Icons.cloud_download_outlined, size: 17),
                            label: const Text('Restore from Drive'),
                            onPressed: () => _restoreFromDrive(appState, auth),
                          ),
                          const SizedBox(height: 10),
                          Text('Last backed up: ${_formatLastBackup(appState.settings.driveLastBackup)}',
                              style: TextStyle(fontSize: 12.5, color: c.textDim, fontWeight: FontWeight.w600)),
                        ],
                      )
                    : ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Icon(Icons.login, color: c.accent),
                        title: const Text('Google se Sign In karein'),
                        subtitle: const Text('Cloud sync, Drive backup aur data sharing ke liye'),
                        onTap: () => auth.signIn(),
                      ),
              ),
              const SectionHead(title: 'Appearance'),
              AppCard(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 4),
                child: Column(
                  children: [
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Dark Theme'),
                      subtitle: const Text('App ka look badlein'),
                      value: appState.settings.theme == 'dark',
                      onChanged: (v) {
                        appState.settings.theme = v ? 'dark' : 'light';
                        appState.scheduleSave();
                      },
                    ),
                    const Divider(height: 1),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('English'),
                      subtitle: const Text('Hindi (Hinglish) se switch karein'),
                      value: appState.settings.language == 'en',
                      onChanged: (v) {
                        appState.settings.language = v ? 'en' : 'hi';
                        appState.scheduleSave();
                      },
                    ),
                  ],
                ),
              ),
              const SectionHead(title: 'Local Backup'),
              AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    ElevatedButton.icon(
                      icon: const Icon(Icons.download_outlined, size: 17),
                      label: const Text('Backup Export Karein'),
                      onPressed: () => _exportLocalBackup(appState),
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.upload_outlined, size: 17),
                      label: const Text('Backup Restore Karein'),
                      onPressed: () => _restoreLocalBackup(appState),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Sirf hisab-kitab (ledger) data export hota hai. Profile photos device par hi local rehti hain aur backup mein shamil nahi hoti.',
                      style: TextStyle(fontSize: 11.5, color: c.textFaint, height: 1.4),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Center(
                child: Text('Embroidery Ledger · v1.0',
                    style: TextStyle(fontSize: 12, color: c.textFaint, fontWeight: FontWeight.w500)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
