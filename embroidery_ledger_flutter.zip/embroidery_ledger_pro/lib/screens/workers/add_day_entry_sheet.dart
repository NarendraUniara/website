import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/shift_entry.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';

/// Mirrors openDayEntryModal()/renderDayEntryModal(): a day-chip picker,
/// absent toggle, shift dropdown, stitches/hours/rate/advance fields and a
/// live "today's earning" preview.
class AddDayEntrySheet extends StatefulWidget {
  final String workerId;
  final int year;
  final int month;
  final String? editEntryId;

  const AddDayEntrySheet({
    super.key,
    required this.workerId,
    required this.year,
    required this.month,
    this.editEntryId,
  });

  @override
  State<AddDayEntrySheet> createState() => _AddDayEntrySheetState();
}

class _AddDayEntrySheetState extends State<AddDayEntrySheet> {
  final _stitchesCtrl = TextEditingController();
  final _rateCtrl = TextEditingController();
  final _hoursCtrl = TextEditingController();
  final _advanceCtrl = TextEditingController();
  bool _absent = false;
  String _shift = 'full';
  int _day = 1;
  String? _entryId;

  bool get _isEdit => _entryId != null;

  @override
  void initState() {
    super.initState();
    final appState = context.read<AppState>();
    _entryId = widget.editEntryId;
    if (_entryId != null) {
      final e = appState.entries.firstWhere((e) => e.id == _entryId);
      _loadFrom(e);
    } else {
      final worker = appState.getWorker(widget.workerId);
      final dim = daysInMonth(widget.year, widget.month);
      final usedDays = _usedDays(appState);
      _day = usedDays.length < dim ? _firstFreeDay(usedDays, dim) : 1;
      _rateCtrl.text = worker != null && worker.rate > 0 ? worker.rate.toStringAsFixed(2) : '';
    }
  }

  void _loadFrom(ShiftEntry e) {
    _entryId = e.id;
    _day = e.day;
    _absent = e.absent;
    _shift = e.shift;
    _stitchesCtrl.text = e.stitches == 0 ? '' : _trimZero(e.stitches);
    _hoursCtrl.text = e.hours == 0 ? '' : _trimZero(e.hours);
    _rateCtrl.text = e.rate == 0 ? '' : e.rate.toStringAsFixed(2);
    _advanceCtrl.text = e.advance == 0 ? '' : _trimZero(e.advance);
  }

  String _trimZero(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();

  Set<int> _usedDays(AppState appState) => appState.entries
      .where((e) =>
          e.workerId == widget.workerId &&
          e.year == widget.year &&
          e.month == widget.month &&
          e.id != _entryId)
      .map((e) => e.day)
      .toSet();

  int _firstFreeDay(Set<int> used, int dim) {
    for (var d = 1; d <= dim; d++) {
      if (!used.contains(d)) return d;
    }
    return 1;
  }

  @override
  void dispose() {
    _stitchesCtrl.dispose();
    _rateCtrl.dispose();
    _hoursCtrl.dispose();
    _advanceCtrl.dispose();
    super.dispose();
  }

  void _pickDay(int d, AppState appState) {
    final conflict = appState.entries
        .where((e) => e.workerId == widget.workerId && e.year == widget.year && e.month == widget.month && e.day == d)
        .toList();
    setState(() {
      if (conflict.isNotEmpty) {
        _loadFrom(conflict.first);
      } else {
        _day = d;
        _entryId = null;
        _stitchesCtrl.clear();
        _hoursCtrl.clear();
        _advanceCtrl.clear();
      }
    });
  }

  void _save() {
    final appState = context.read<AppState>();
    final stitches = _absent ? 0.0 : (double.tryParse(_stitchesCtrl.text.trim()) ?? 0);
    final hours = _absent ? 0.0 : (double.tryParse(_hoursCtrl.text.trim()) ?? 0);
    final rate = double.tryParse(_rateCtrl.text.trim()) ?? 0;
    final advance = double.tryParse(_advanceCtrl.text.trim()) ?? 0;

    if (_isEdit) {
      final idx = appState.entries.indexWhere((e) => e.id == _entryId);
      if (idx != -1) {
        final old = appState.entries[idx];
        appState.entries[idx] = ShiftEntry(
          id: old.id,
          workerId: old.workerId,
          year: old.year,
          month: old.month,
          day: _day,
          absent: _absent,
          shift: _shift,
          stitches: stitches,
          rate: rate,
          hours: hours,
          advance: advance,
          createdAt: old.createdAt,
        );
      }
    } else {
      appState.entries.add(
        ShiftEntry(
          id: newId(),
          workerId: widget.workerId,
          year: widget.year,
          month: widget.month,
          day: _day,
          absent: _absent,
          shift: _shift,
          stitches: stitches,
          rate: rate,
          hours: hours,
          advance: advance,
          createdAt: DateTime.now().millisecondsSinceEpoch,
        ),
      );
    }
    appState.scheduleSave();
    Navigator.of(context).pop();
  }

  void _delete() {
    final appState = context.read<AppState>();
    appState.entries.removeWhere((e) => e.id == _entryId);
    appState.scheduleSave();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);
    final dim = daysInMonth(widget.year, widget.month);
    final usedDays = _usedDays(appState);
    final payVal = _absent ? 0.0 : (double.tryParse(_stitchesCtrl.text.trim()) ?? 0) * (double.tryParse(_rateCtrl.text.trim()) ?? 0);

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(_isEdit ? 'Entry Edit Karein' : 'Nayi Entry',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.text)),
            const SizedBox(height: 14),
            Text('Din Chunein', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: c.textDim)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: [
                for (var d = 1; d <= dim; d++)
                  _DayChip(
                    day: d,
                    selected: d == _day,
                    taken: usedDays.contains(d),
                    onTap: () => _pickDay(d, appState),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () => setState(() => _absent = !_absent),
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: _absent ? c.redSoft : c.bgInput,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _absent ? c.red : c.border, width: 1.5),
                      ),
                      child: Text('✕ Aaj Absent',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, color: _absent ? c.red : c.textDim, fontSize: 13)),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Opacity(
                    opacity: _absent ? 0.35 : 1,
                    child: IgnorePointer(
                      ignoring: _absent,
                      child: DropdownButtonFormField<String>(
                        value: _shift,
                        isExpanded: true,
                        decoration: const InputDecoration(labelText: 'Shift'),
                        items: [
                          for (final s in ShiftType.all)
                            DropdownMenuItem(value: s.id, child: Text('${s.icon} ${s.en}', overflow: TextOverflow.ellipsis)),
                        ],
                        onChanged: (v) => setState(() => _shift = v ?? _shift),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Opacity(
              opacity: _absent ? 0.35 : 1,
              child: IgnorePointer(
                ignoring: _absent,
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _stitchesCtrl,
                            decoration: const InputDecoration(labelText: 'Stitches'),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _hoursCtrl,
                            decoration: const InputDecoration(labelText: 'Hours'),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _rateCtrl,
                            decoration: const InputDecoration(labelText: 'Rate (₹)'),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                            onChanged: (_) => setState(() {}),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _advanceCtrl,
                            decoration: const InputDecoration(labelText: 'Advance (₹)'),
                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _absent ? c.redSoft : c.bgSoft,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  Text('Aaj Ki Earning', style: TextStyle(fontSize: 11.5, color: c.textFaint, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 3),
                  Text(_absent ? 'Absent' : money(payVal),
                      style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w800,
                          color: _absent ? c.red : c.text)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _save,
                    child: Text(_isEdit ? 'Update' : 'Save'),
                  ),
                ),
              ],
            ),
            if (_isEdit) ...[
              const SizedBox(height: 10),
              Center(
                child: TextButton(
                  onPressed: _delete,
                  child: const Text('Entry Delete Karein', style: TextStyle(color: Colors.red)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _DayChip extends StatelessWidget {
  final int day;
  final bool selected;
  final bool taken;
  final VoidCallback onTap;

  const _DayChip({required this.day, required this.selected, required this.taken, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    Color bg = c.bgInput;
    Color fg = c.textDim;
    Color border = c.border;
    if (selected) {
      bg = c.accent;
      fg = Colors.white;
      border = c.accent;
    } else if (taken) {
      bg = c.bgSoft;
      fg = c.textFaint;
    }
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        width: 34,
        height: 34,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(9), border: Border.all(color: border)),
        child: Text('$day', style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: 12.5)),
      ),
    );
  }
}
