import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';

/// Mirrors openAddNextMonthModal() / confirmAddNextMonth(): starts the next
/// unpaid month for a worker, offering to carry forward or settle-now any
/// outstanding baki from the previous month.
class AddNextMonthSheet extends StatefulWidget {
  final String workerId;
  final void Function(int year, int month) onStarted;

  const AddNextMonthSheet({super.key, required this.workerId, required this.onStarted});

  @override
  State<AddNextMonthSheet> createState() => _AddNextMonthSheetState();
}

class _AddNextMonthSheetState extends State<AddNextMonthSheet> {
  bool _settleNow = false;

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);
    final target = appState.nextMonthTarget(widget.workerId);

    if (target.alreadyExists) {
      // Already exists — just navigate straight there.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.of(context).pop();
        widget.onStarted(target.year, target.month);
      });
      return const SizedBox.shrink();
    }

    final hasPrev = target.prev != null;
    final prevPositive = hasPrev && target.prevBaki > 0.5;
    final prevNegative = hasPrev && target.prevBaki < -0.5;

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 18,
        bottom: MediaQuery.of(context).viewInsets.bottom + 18,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Naya Mahina Shuru Karein', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.text)),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: c.bgSoft, borderRadius: BorderRadius.circular(12)),
            child: Column(
              children: [
                Text('AGLA MAHINA', style: TextStyle(fontSize: 11, color: c.textFaint, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                const SizedBox(height: 6),
                Text(monthLabel(target.year, target.month),
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: c.text)),
              ],
            ),
          ),
          if (prevPositive) ...[
            const SizedBox(height: 14),
            Text('PICHLE MAHINE KA BAKI ${money(target.prevBaki)}',
                style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: c.textFaint, letterSpacing: 0.3)),
            const SizedBox(height: 8),
            _settleOption(
              context,
              selected: !_settleNow,
              title: 'Carry Forward Karein',
              subtitle: 'Baki agle mahine mein jud jayega',
              onTap: () => setState(() => _settleNow = false),
            ),
            const SizedBox(height: 8),
            _settleOption(
              context,
              selected: _settleNow,
              title: 'Abhi Settle Karein',
              subtitle: 'Poora baki abhi paid maan liya jayega',
              onTap: () => setState(() => _settleNow = true),
            ),
          ] else if (prevNegative) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: c.blueSoft, borderRadius: BorderRadius.circular(10)),
              child: Text(
                'Pichle mahine ${money(target.prevBaki.abs())} extra diya gaya hai — ye agle mahine adjust ho jayega.',
                style: TextStyle(fontSize: 12.5, color: c.text, fontWeight: FontWeight.w500),
              ),
            ),
          ],
          if (hasPrev) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: c.accentSoft, borderRadius: BorderRadius.circular(8)),
              child: Text(
                '${monthLabel(target.prev!.year, target.prev!.month)} lock ho jayega — usme koi badlav nahi ho payega.',
                style: TextStyle(fontSize: 11.5, color: c.textDim, fontWeight: FontWeight.w500),
              ),
            ),
          ],
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () {
                    appState.startNextMonth(widget.workerId, target.year, target.month, target.prev, _settleNow);
                    Navigator.of(context).pop();
                    widget.onStarted(target.year, target.month);
                  },
                  child: const Text('Mahina Shuru Karein'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _settleOption(BuildContext context,
      {required bool selected, required String title, required String subtitle, required VoidCallback onTap}) {
    final c = appColors(context);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected ? c.accentSoft : c.bgElevated,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: selected ? c.accent : c.border, width: 1.5),
        ),
        child: Row(
          children: [
            Icon(selected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                color: selected ? c.accent : c.textFaint, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(fontWeight: FontWeight.w700, color: c.text, fontSize: 13.5)),
                  Text(subtitle, style: TextStyle(fontSize: 11.5, color: c.textFaint)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
