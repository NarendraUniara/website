import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/worker.dart';
import '../../services/image_service.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';
import 'add_next_month_sheet.dart';
import 'delete_months_sheet.dart';
import 'edit_worker_sheet.dart';
import 'month_detail_screen.dart';
import 'share_access_sheet.dart';

/// Mirrors viewWorkerProfile(): avatar/name/rate/phone header, all-time
/// earnings highlight, and a "Monthly Hisab" list of per-month stat cards
/// with a button to start the next month (carry-forward/settle-now).
class WorkerProfileScreen extends StatefulWidget {
  final String workerId;

  const WorkerProfileScreen({super.key, required this.workerId});

  @override
  State<WorkerProfileScreen> createState() => _WorkerProfileScreenState();
}

class _WorkerProfileScreenState extends State<WorkerProfileScreen> {
  final _imageService = ImageService();
  bool _pickingPhoto = false;

  Future<void> _changePhoto(AppState appState, Worker worker) async {
    setState(() => _pickingPhoto = true);
    try {
      final photo = await _imageService.pickAndCompressWorkerPhoto();
      if (photo != null) {
        worker.photoUrl = photo;
        appState.scheduleSave();
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Photo load nahi hui, dobara try karein')));
      }
    } finally {
      if (mounted) setState(() => _pickingPhoto = false);
    }
  }

  void _removePhoto(AppState appState, Worker worker) {
    worker.photoUrl = null;
    appState.scheduleSave();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);
    final workerId = widget.workerId;
    final worker = appState.getWorker(workerId);

    if (worker == null) {
      return const Scaffold(body: Center(child: Text('Worker not found')));
    }

    final stats = appState.getWorkerAllTimeStats(workerId);
    final months = appState.getWorkerMonths(workerId);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Worker Profile'),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_horiz),
            onPressed: () => _openWorkerMenu(context, appState),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: _pickingPhoto ? null : () => _changePhoto(appState, worker),
                child: Opacity(
                  opacity: _pickingPhoto ? 0.5 : 1,
                  child: Stack(
                    children: [
                      AppAvatar(name: worker.name, photoUrl: worker.photoUrl, size: 72),
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                              color: c.accent,
                              shape: BoxShape.circle,
                              border: Border.all(color: c.bgElevated, width: 2)),
                          child: const Icon(Icons.camera_alt, size: 12, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(worker.name, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: c.text)),
                    const SizedBox(height: 3),
                    Text('Rate: ${money(worker.rate)} per stitch',
                        style: TextStyle(fontSize: 12.5, color: c.textDim, fontWeight: FontWeight.w600)),
                    if ((worker.phone ?? worker.contact)?.isNotEmpty == true) ...[
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(Icons.call_outlined, size: 13, color: c.accent),
                          const SizedBox(width: 4),
                          Text(worker.phone ?? worker.contact ?? '',
                              style: TextStyle(fontSize: 12.5, color: c.accent, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ],
                    if (worker.shareOn && worker.shareEmail != null) ...[
                      const SizedBox(height: 6),
                      const StatusBadge('Shared', tone: BadgeTone.blue),
                    ],
                  ],
                ),
              ),
            ],
          ),
          if ((worker.bio ?? '').isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(worker.bio!, style: TextStyle(fontSize: 13, color: c.textDim, height: 1.4)),
          ],
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: c.accentGradient,
              borderRadius: BorderRadius.circular(14),
              boxShadow: c.shadowLg,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('TOTAL EARNED (ALL TIME)',
                    style: TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                const SizedBox(height: 4),
                Text(money(stats.totalEarned),
                    style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
          SectionHead(
            title: 'Monthly Hisab',
            subtitle: 'Tap karke details dekhein',
            onAdd: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (_) => AddNextMonthSheet(
                workerId: workerId,
                onStarted: (y, m) => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => MonthDetailScreen(workerId: workerId, year: y, month: m)),
                ),
              ),
            ),
          ),
          if (months.isEmpty)
            const EmptyState(
              emoji: '📅',
              title: 'Koi mahina nahi hai',
              subtitle: '+ dabakar pehla mahina shuru karein',
            )
          else
            ...months.map((mo) {
              final ms = appState.getMonthStats(workerId, mo.year, mo.month);
              return AppCard(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => MonthDetailScreen(workerId: workerId, year: mo.year, month: mo.month),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(monthLabel(mo.year, mo.month),
                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: c.text)),
                    Divider(color: c.border, height: 18),
                    StatGrid(cells: [
                      StatCell(label: 'Working Days', value: '${ms.workingDays}'),
                      StatCell(label: 'Total Earned', value: money(ms.totalEarned), valueColor: c.blue),
                      StatCell(label: 'Total Stitches', value: numberIN(ms.totalStitches)),
                      StatCell(label: 'Advance', value: money(ms.totalAdvance)),
                      StatCell(label: 'Salary Paid', value: money(ms.salaryPaid), valueColor: c.green),
                      StatCell(
                        label: 'Baki',
                        value: ms.settled
                            ? 'Settled ✓${ms.totalPaid > 0.5 ? ' · ${money(ms.totalPaid)}' : ''}'
                            : money(ms.baki),
                        valueColor: ms.settled ? c.green : (ms.baki > 0.5 ? c.amber : c.green),
                      ),
                    ]),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  void _openWorkerMenu(BuildContext context, AppState appState) {
    final worker = appState.getWorker(widget.workerId);
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('Profile Edit Karein'),
              onTap: () {
                Navigator.of(ctx).pop();
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => EditWorkerSheet(workerId: widget.workerId),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.share_outlined),
              title: const Text('Share Access'),
              onTap: () {
                Navigator.of(ctx).pop();
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => ShareAccessSheet(workerId: widget.workerId),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_sweep_outlined),
              title: const Text('Months Delete Karein'),
              onTap: () {
                Navigator.of(ctx).pop();
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => DeleteMonthsSheet(workerId: widget.workerId),
                );
              },
            ),
            if (worker?.photoUrl != null)
              ListTile(
                leading: const Icon(Icons.no_photography_outlined),
                title: const Text('Photo Hatayein'),
                onTap: () {
                  Navigator.of(ctx).pop();
                  if (worker != null) _removePhoto(appState, worker);
                },
              ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('Worker Delete Karein', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.of(ctx).pop();
                showDialog(
                  context: context,
                  builder: (dctx) => AlertDialog(
                    title: const Text('Worker Delete Karein?'),
                    content: const Text('Sab entries aur payments delete ho jayengi.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.of(dctx).pop(), child: const Text('Cancel')),
                      TextButton(
                        onPressed: () {
                          appState.deleteWorker(widget.workerId);
                          Navigator.of(dctx).pop();
                          Navigator.of(context).pop();
                        },
                        child: const Text('Delete', style: TextStyle(color: Colors.red)),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
