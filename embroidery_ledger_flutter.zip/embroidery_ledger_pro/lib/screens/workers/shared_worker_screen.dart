import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/month_meta.dart';
import '../../models/payment.dart';
import '../../models/shift_entry.dart';
import '../../models/worker.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';

class _SharedMonthStat {
  final int year;
  final int month;
  final int workingDays;
  final double totalStitches;
  final double totalEarned;
  final double totalAdvance;
  final double salaryPaid;
  final double opening;
  final bool settled;
  const _SharedMonthStat({
    required this.year,
    required this.month,
    required this.workingDays,
    required this.totalStitches,
    required this.totalEarned,
    required this.totalAdvance,
    required this.salaryPaid,
    required this.opening,
    required this.settled,
  });

  double get baki => totalEarned + opening - totalAdvance - salaryPaid;
}

/// Mirrors sharedWorkerCardHtml() + the sharedViewData rendering path: a
/// read-only view of a worker's hisab that someone else shared with the
/// signed-in account. Fetched fresh from Firestore each time it's opened.
class SharedWorkerScreen extends StatefulWidget {
  const SharedWorkerScreen({super.key});

  @override
  State<SharedWorkerScreen> createState() => _SharedWorkerScreenState();
}

class _SharedWorkerScreenState extends State<SharedWorkerScreen> {
  late Future<Map<String, dynamic>?> _future;

  @override
  void initState() {
    super.initState();
    _future = context.read<AppState>().fetchSharedData();
  }

  List<_SharedMonthStat> _computeMonths(
      List<ShiftEntry> entries, List<Payment> payments, Map<String, MonthMeta> monthMeta) {
    final keys = <String>{};
    for (final e in entries) {
      keys.add('${e.year}_${e.month}');
    }
    for (final p in payments) {
      keys.add('${p.year}_${p.month}');
    }
    for (final k in monthMeta.keys) {
      final parts = k.split('_');
      if (parts.length >= 3) keys.add('${parts[parts.length - 2]}_${parts[parts.length - 1]}');
    }

    final result = <_SharedMonthStat>[];
    for (final key in keys) {
      final parts = key.split('_');
      final y = int.parse(parts[0]);
      final m = int.parse(parts[1]);
      final monthEntries = entries.where((e) => e.year == y && e.month == m && !e.absent).toList();
      final workingDays = entries.where((e) => e.year == y && e.month == m).length;
      final totalStitches = monthEntries.fold<double>(0, (s, e) => s + e.stitches);
      final totalEarned = monthEntries.fold<double>(0, (s, e) => s + e.earned);
      final entryAdvance = entries
          .where((e) => e.year == y && e.month == m)
          .fold<double>(0, (s, e) => s + e.advance);
      final monthPayments = payments.where((p) => p.year == y && p.month == m).toList();
      final paymentAdvance = monthPayments
          .where((p) => p.type == PaymentType.advance)
          .fold<double>(0, (s, p) => s + p.amount);
      final salaryPaid = monthPayments
          .where((p) => p.type == PaymentType.salary)
          .fold<double>(0, (s, p) => s + p.amount);
      final meta = monthMeta[_findMetaKey(monthMeta, y, m)] ?? const MonthMeta();
      result.add(_SharedMonthStat(
        year: y,
        month: m,
        workingDays: workingDays,
        totalStitches: totalStitches,
        totalEarned: totalEarned,
        totalAdvance: entryAdvance + paymentAdvance,
        salaryPaid: salaryPaid,
        opening: meta.openingBalance,
        settled: meta.settled,
      ));
    }
    result.sort((a, b) => b.year != a.year ? b.year - a.year : b.month - a.month);
    return result;
  }

  String _findMetaKey(Map<String, MonthMeta> monthMeta, int y, int m) {
    for (final k in monthMeta.keys) {
      if (k.endsWith('_${y}_$m')) return k;
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Shared Hisab')),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snap.data;
          if (data == null) {
            return const EmptyState(
              emoji: '🔗',
              title: 'Kuch bhi share nahi kiya gaya',
              subtitle: 'Jab koi apna worker aapke email par share karega, wo yahan dikhega',
            );
          }
          try {
            final worker = Worker.fromJson(data['worker'] as Map<String, dynamic>);
            final entries = (data['entries'] as List<dynamic>? ?? [])
                .map((e) => ShiftEntry.fromJson(e as Map<String, dynamic>))
                .toList();
            final payments = (data['payments'] as List<dynamic>? ?? [])
                .map((e) => Payment.fromJson(e as Map<String, dynamic>))
                .toList();
            final monthMeta = (data['monthMeta'] as Map<String, dynamic>? ?? {})
                .map((k, v) => MapEntry(k, MonthMeta.fromJson(v as Map<String, dynamic>)));
            final months = _computeMonths(entries, payments, monthMeta);
            final totalEarned = entries.where((e) => !e.absent).fold<double>(0, (s, e) => s + e.earned);

            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
              children: [
                Row(
                  children: [
                    AppAvatar(name: worker.name, photoUrl: worker.photoUrl, size: 60),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(worker.name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.text)),
                          Text('${money(worker.rate)} / stitch', style: TextStyle(fontSize: 12.5, color: c.textDim)),
                          const SizedBox(height: 6),
                          const StatusBadge('Shared with you', tone: BadgeTone.blue),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                HeroCard(label: 'Total Earned (All Time)', amount: money(totalEarned)),
                const SectionHead(title: 'Monthly Hisab', subtitle: 'Read-only'),
                if (months.isEmpty)
                  const EmptyState(emoji: '📅', title: 'Koi mahina nahi hai', subtitle: '')
                else
                  ...months.map((ms) => AppCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(monthLabel(ms.year, ms.month),
                                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: c.text)),
                            Divider(color: c.border, height: 18),
                            StatGrid(cells: [
                              StatCell(label: 'Working Days', value: '${ms.workingDays}'),
                              StatCell(label: 'Total Earned', value: money(ms.totalEarned), valueColor: c.blue),
                              StatCell(label: 'Advance', value: money(ms.totalAdvance)),
                              StatCell(label: 'Salary Paid', value: money(ms.salaryPaid), valueColor: c.green),
                              StatCell(
                                label: 'Baki',
                                value: ms.settled ? 'Settled ✓' : money(ms.baki),
                                valueColor: ms.settled ? c.green : (ms.baki > 0.5 ? c.amber : c.green),
                              ),
                            ]),
                          ],
                        ),
                      )),
              ],
            );
          } catch (_) {
            return const EmptyState(emoji: '⚠️', title: 'Data load nahi hui', subtitle: 'Dobara try karein');
          }
        },
      ),
    );
  }
}
