import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';
import '../../utils/app_theme.dart';

/// Mirrors openEditProfileModal()/saveWorkerProfileFields() and
/// openEditRateModal()/saveEditRate(): edit a worker's name, phone, bio and
/// per-stitch rate in one sheet.
class EditWorkerSheet extends StatefulWidget {
  final String workerId;
  const EditWorkerSheet({super.key, required this.workerId});

  @override
  State<EditWorkerSheet> createState() => _EditWorkerSheetState();
}

class _EditWorkerSheetState extends State<EditWorkerSheet> {
  late TextEditingController _nameCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _bioCtrl;
  late TextEditingController _rateCtrl;

  @override
  void initState() {
    super.initState();
    final appState = context.read<AppState>();
    final w = appState.getWorker(widget.workerId);
    _nameCtrl = TextEditingController(text: w?.name ?? '');
    _phoneCtrl = TextEditingController(text: w?.phone ?? w?.contact ?? '');
    _bioCtrl = TextEditingController(text: w?.bio ?? '');
    _rateCtrl = TextEditingController(text: w != null && w.rate > 0 ? _trim(w.rate) : '');
  }

  String _trim(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _bioCtrl.dispose();
    _rateCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Naam daalein')));
      return;
    }
    final appState = context.read<AppState>();
    final w = appState.getWorker(widget.workerId);
    if (w == null) return;
    w.name = name;
    w.phone = _phoneCtrl.text.trim().isEmpty ? null : _phoneCtrl.text.trim();
    w.bio = _bioCtrl.text.trim().isEmpty ? null : _bioCtrl.text.trim();
    w.rate = double.tryParse(_rateCtrl.text.trim()) ?? w.rate;
    appState.scheduleSave();
    appState.resyncIfShared(widget.workerId);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Profile Edit Karein', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.text)),
            const SizedBox(height: 16),
            TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Worker ka Naam'), autofocus: true),
            const SizedBox(height: 12),
            TextField(
              controller: _phoneCtrl,
              decoration: const InputDecoration(labelText: 'Phone Number'),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _bioCtrl,
              decoration: const InputDecoration(labelText: 'Bio (optional)'),
              maxLines: 3,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _rateCtrl,
              decoration: const InputDecoration(labelText: 'Rate per Stitch (₹)'),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                ),
                const SizedBox(width: 12),
                Expanded(child: ElevatedButton(onPressed: _save, child: const Text('Save'))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
