import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/auth_service.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';

/// Mirrors openShareAccessModal(): a toggle to turn sharing on/off for this
/// worker, plus the email it's shared to. Requires being signed in (the
/// data is synced to Firestore, keyed by that email).
class ShareAccessSheet extends StatefulWidget {
  final String workerId;
  const ShareAccessSheet({super.key, required this.workerId});

  @override
  State<ShareAccessSheet> createState() => _ShareAccessSheetState();
}

class _ShareAccessSheetState extends State<ShareAccessSheet> {
  late TextEditingController _emailCtrl;

  @override
  void initState() {
    super.initState();
    final w = context.read<AppState>().getWorker(widget.workerId);
    _emailCtrl = TextEditingController(text: w?.shareEmail ?? '');
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final auth = context.read<AuthService>();
    final c = appColors(context);
    final w = appState.getWorker(widget.workerId);
    final signedIn = auth.currentUser != null;

    if (w == null) return const SizedBox.shrink();

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 18,
        bottom: MediaQuery.of(context).viewInsets.bottom + 18,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Share Access', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.text)),
          const SizedBox(height: 6),
          Text(
            'Is worker ka hisab-kitab kisi aur ke Embroidery Ledger account ke saath read-only share karein.',
            style: TextStyle(fontSize: 12.5, color: c.textDim, height: 1.4),
          ),
          const SizedBox(height: 14),
          if (!signedIn)
            Container(
              padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(color: c.amberSoft, borderRadius: BorderRadius.circular(10)),
              child: Text('Share karne ke liye pehle Google se Sign In karein.',
                  style: TextStyle(color: c.amber, fontSize: 12.5, fontWeight: FontWeight.w600)),
            ),
          const SizedBox(height: 10),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Share Access'),
            subtitle: const Text('On karein taaki dusra insaan dekh sake'),
            value: w.shareOn,
            onChanged: !signedIn ? null : (v) => appState.toggleWorkerShare(widget.workerId, v),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _emailCtrl,
            enabled: signedIn,
            decoration: const InputDecoration(labelText: 'Unka Email'),
            keyboardType: TextInputType.emailAddress,
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: !signedIn
                ? null
                : () {
                    appState.saveWorkerShareEmail(widget.workerId, _emailCtrl.text.trim());
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Email save ho gaya')));
                  },
            child: const Text('Email Save Karein'),
          ),
          if (w.shareOn && w.shareEmail != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: c.accentSoft, borderRadius: BorderRadius.circular(8)),
              child: Text('✓ Shared with ${w.shareEmail}',
                  style: TextStyle(fontSize: 12, color: c.text, fontWeight: FontWeight.w600)),
            ),
          ],
          const SizedBox(height: 16),
          OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Band Karein')),
        ],
      ),
    );
  }
}
