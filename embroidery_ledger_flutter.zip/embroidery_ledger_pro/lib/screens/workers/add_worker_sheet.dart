import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/worker.dart';
import '../../services/image_service.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../widgets/app_widgets.dart';

/// Mirrors openAddWorkerModal()/saveNewWorker(): name, phone, rate, and an
/// optional compressed photo (tap the avatar to pick one from the gallery).
class AddWorkerSheet extends StatefulWidget {
  const AddWorkerSheet({super.key});

  @override
  State<AddWorkerSheet> createState() => _AddWorkerSheetState();
}

class _AddWorkerSheetState extends State<AddWorkerSheet> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _rateCtrl = TextEditingController();
  final _imageService = ImageService();
  String? _photo;
  bool _pickingPhoto = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _rateCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    setState(() => _pickingPhoto = true);
    try {
      final photo = await _imageService.pickAndCompressWorkerPhoto();
      if (photo != null) setState(() => _photo = photo);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Photo load nahi hui, dobara try karein')));
      }
    } finally {
      if (mounted) setState(() => _pickingPhoto = false);
    }
  }

  void _save() {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) return;
    final appState = context.read<AppState>();
    appState.addWorker(
      Worker(
        id: newId(),
        name: name,
        phone: _phoneCtrl.text.trim().isEmpty ? null : _phoneCtrl.text.trim(),
        rate: double.tryParse(_rateCtrl.text.trim()) ?? 0,
        photoUrl: _photo,
        sortIndex: appState.workers.length,
      ),
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Naya Worker', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.text)),
          const SizedBox(height: 16),
          Center(
            child: GestureDetector(
              onTap: _pickingPhoto ? null : _pickPhoto,
              child: Opacity(
                opacity: _pickingPhoto ? 0.5 : 1,
                child: Stack(
                  children: [
                    AppAvatar(name: _nameCtrl.text.isEmpty ? '?' : _nameCtrl.text, photoUrl: _photo, size: 72),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(color: c.accent, shape: BoxShape.circle, border: Border.all(color: c.bgElevated, width: 2)),
                        child: const Icon(Icons.camera_alt, size: 13, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text('Tap karke photo chunein', style: TextStyle(fontSize: 11.5, color: c.textFaint)),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _nameCtrl,
            decoration: const InputDecoration(labelText: 'Naam'),
            autofocus: true,
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _phoneCtrl,
            decoration: const InputDecoration(labelText: 'Phone Number'),
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _rateCtrl,
            decoration: const InputDecoration(labelText: 'Rate per Stitch (₹)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: _save, child: const Text('Save')),
        ],
      ),
    );
  }
}
