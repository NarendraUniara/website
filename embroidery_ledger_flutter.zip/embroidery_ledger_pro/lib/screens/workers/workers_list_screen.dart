import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/auth_service.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';
import '../settings/settings_screen.dart';
import 'add_worker_sheet.dart';
import 'shared_worker_screen.dart';
import 'worker_profile_screen.dart';

/// Mirrors viewWorkersList(): topbar with title + settings/add buttons,
/// section head with worker count, and drag-reorderable worker cards
/// (avatar, rate/working-days meta, status badge).
class WorkersListScreen extends StatelessWidget {
  const WorkersListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final auth = context.read<AuthService>();
    final c = appColors(context);
    final workers = appState.workers;
    final signedIn = auth.currentUser != null;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Expanded(
                    child: TopbarTitle(title: 'Embroidery Ledger', subtitle: 'Worker payroll & khata'),
                  ),
                  if (signedIn) ...[
                    HeadPlusButton(
                      secondary: true,
                      icon: Icons.link,
                      onTap: () => Navigator.of(context)
                          .push(MaterialPageRoute(builder: (_) => const SharedWorkerScreen())),
                    ),
                    const SizedBox(width: 8),
                  ],
                  HeadPlusButton(
                    secondary: true,
                    icon: Icons.settings_outlined,
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
                  ),
                  const SizedBox(width: 8),
                  HeadPlusButton(
                    onTap: () => showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      builder: (_) => const AddWorkerSheet(),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: workers.isEmpty
                  ? ListView(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      children: [
                        SectionHead(title: 'Workers', subtitle: '0 total'),
                        const EmptyState(
                          emoji: '🧵',
                          title: 'Koi worker nahi hai',
                          subtitle: 'Pehla worker add karke shuru karein',
                        ),
                      ],
                    )
                  : ReorderableListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      header: SectionHead(title: 'Workers', subtitle: '${workers.length} total'),
                      itemCount: workers.length,
                      onReorder: (oldIndex, newIndex) {
                        var ni = newIndex;
                        if (ni > oldIndex) ni -= 1;
                        final list = [...workers];
                        final item = list.removeAt(oldIndex);
                        list.insert(ni, item);
                        appState.reorderWorkers(list);
                      },
                      itemBuilder: (context, i) {
                        final w = workers[i];
                        final allTime = appState.getWorkerAllTimeStats(w.id);
                        final months = appState.getWorkerMonths(w.id);
                        final activeMonth = months.isNotEmpty ? months.first : null;
                        final ms = activeMonth != null
                            ? appState.getMonthStats(w.id, activeMonth.year, activeMonth.month)
                            : null;
                        final hasActivity =
                            allTime.workingDays > 0 || allTime.totalAdvance > 0.5 || allTime.salaryPaid > 0.5;
                        Widget statusBadge;
                        if (!hasActivity) {
                          statusBadge = const StatusBadge('No Data');
                        } else if (allTime.outstanding > 0.5) {
                          statusBadge = StatusBadge('Baki ${money(allTime.outstanding)}', tone: BadgeTone.amber);
                        } else {
                          statusBadge = const StatusBadge('Settled ✓', tone: BadgeTone.green);
                        }
                        return ListRowCard(
                          key: ValueKey(w.id),
                          leading: AppAvatar(name: w.name, photoUrl: w.photoUrl),
                          title: w.name,
                          subtitle: '${money(w.rate)} / stitch · ${ms?.workingDays ?? 0} din',
                          badges: [
                            statusBadge,
                            if (w.shareOn) const StatusBadge('Shared', tone: BadgeTone.blue),
                          ],
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => WorkerProfileScreen(workerId: w.id)),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
