import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/shift_entry.dart';
import '../../models/month_meta.dart';
import '../../services/pdf_service.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';
import 'add_day_entry_sheet.dart';
import 'add_salary_payment_sheet.dart';

/// Mirrors viewMonthDetail(): opening-balance badge, stat grid, "Add salary
/// payment" action, and a scrollable list of day cards (day number + month,
/// stitches/rate/hours/advance, shift tag, today's earning).
class MonthDetailScreen extends StatelessWidget {
  final String workerId;
  final int year;
  final int month;

  const MonthDetailScreen({
    super.key,
    required this.workerId,
    required this.year,
    required this.month,
  });

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);
    final worker = appState.getWorker(workerId);
    if (worker == null) {
      return const Scaffold(body: Center(child: Text('Worker not found')));
    }
    final s = appState.getMonthStats(workerId, year, month);

    return Scaffold(
      appBar: AppBar(
        title: Text(worker.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf_outlined),
            tooltip: 'PDF banao',
            onPressed: () async => PdfService().exportMonthPdf(worker, s, year, month),
          ),
          IconButton(
            icon: const Icon(Icons.share_outlined),
            tooltip: 'Share karo',
            onPressed: () async => PdfService().shareMonthPdf(worker, s, year, month),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Month Delete Karein',
            onPressed: () => _confirmDeleteMonth(context, appState),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Text(monthLabel(year, month), style: TextStyle(color: c.textDim, fontWeight: FontWeight.w600, fontSize: 13)),
          const SizedBox(height: 10),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (s.opening.abs() > 0.5) ...[
                  StatusBadge('From Previous ${money(s.opening)}', tone: BadgeTone.amber),
                  const SizedBox(height: 10),
                ],
                StatGrid(cells: [
                  StatCell(label: 'Working Days', value: '${s.workingDays}'),
                  StatCell(label: 'Total Earned', value: money(s.totalEarned), valueColor: c.blue),
                  StatCell(label: 'Stitches', value: numberIN(s.totalStitches)),
                  StatCell(label: 'Advance', value: money(s.totalAdvance)),
                  StatCell(label: 'Salary Paid', value: money(s.salaryPaid), valueColor: c.green),
                  StatCell(
                    label: 'Baki',
                    value: s.settled
                        ? 'Settled ✓${s.totalPaid > 0.5 ? ' · ${money(s.totalPaid)}' : ''}'
                        : money(s.baki),
                    valueColor: s.settled ? c.green : (s.baki > 0.5 ? c.amber : c.green),
                  ),
                ]),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.check, size: 17),
                    label: const Text('Salary Payment Add Karein'),
                    onPressed: () => showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      builder: (_) => AddSalaryPaymentSheet(workerId: workerId, year: year, month: month),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SectionHead(
            title: 'Daily Records',
            subtitle: 'Har din ki entry',
            onAdd: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (_) => AddDayEntrySheet(workerId: workerId, year: year, month: month),
            ),
          ),
          if (s.entries.isEmpty)
            const EmptyState(emoji: '🗓️', title: 'Koi entry nahi hai', subtitle: '+ dabakar day entry add karein')
          else
            ...s.entries.map((e) => _DayCard(
                  entry: e,
                  month: month,
                  onTap: () => showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    builder: (_) => AddDayEntrySheet(
                      workerId: workerId,
                      year: year,
                      month: month,
                      editEntryId: e.id,
                    ),
                  ),
                )),
        ],
      ),
    );
  }

  void _confirmDeleteMonth(BuildContext context, AppState appState) {
    showDialog(
      context: context,
      builder: (dctx) => AlertDialog(
        title: const Text('Month Delete Karein?'),
        content: Text(
            '${monthLabel(year, month)} ki sab entries delete ho jayengi. Agar iske pichle mahine ye lock tha to wo wapas unlock ho jayega.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dctx).pop(), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              appState.entries.removeWhere((e) => e.workerId == workerId && e.year == year && e.month == month);
              appState.payments.removeWhere((p) => p.workerId == workerId && p.year == year && p.month == month);
              appState.monthMeta.remove(monthMetaKey(workerId, year, month));
              appState.unlockMonthsThatSettledInto(workerId, year, month);
              appState.scheduleSave();
              Navigator.of(dctx).pop();
              Navigator.of(context).pop();
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

class _DayCard extends StatelessWidget {
  final ShiftEntry entry;
  final int month;
  final VoidCallback onTap;

  const _DayCard({required this.entry, required this.month, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    final sh = ShiftType.of(entry.shift);
    return AppCard(
      onTap: onTap,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 46,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: entry.absent ? c.redSoft : c.bgSoft,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: [
                Text('${entry.day}',
                    style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                        color: entry.absent ? c.red : c.text)),
                Text(monthAbbrOf(month),
                    style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700, color: c.textFaint)),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: entry.absent
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Aaj Ki Earning', style: TextStyle(fontSize: 11, color: c.textFaint)),
                      Text('Absent — No Payment', style: TextStyle(color: c.red, fontWeight: FontWeight.w700)),
                    ],
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _drow(c, 'Stitches', numberIN(entry.stitches)),
                      _drow(c, 'Rate', money(entry.rate)),
                      _drow(c, 'Hours', '${entry.hours} hr'),
                      if (entry.advance > 0) _drow(c, 'Advance', money(entry.advance)),
                      const SizedBox(height: 3),
                      Text('Aaj Ki Earning', style: TextStyle(fontSize: 11, color: c.textFaint)),
                      Text(money(entry.earned),
                          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: c.text)),
                      const SizedBox(height: 4),
                      StatusBadge(sh.en, tone: BadgeTone.blue),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _drow(AppColors c, String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 2),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: TextStyle(fontSize: 12, color: c.textDim)),
            Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: c.text)),
          ],
        ),
      );
}
