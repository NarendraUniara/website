import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../models/payment.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';

/// Mirrors openSalaryPaymentModal()/saveSalaryPayment(): shows the current
/// baki, records a salary or advance payment, and warns (with a confirm
/// step) if the amount entered is more than the outstanding baki.
class AddSalaryPaymentSheet extends StatefulWidget {
  final String workerId;
  final int year;
  final int month;

  const AddSalaryPaymentSheet({
    super.key,
    required this.workerId,
    required this.year,
    required this.month,
  });

  @override
  State<AddSalaryPaymentSheet> createState() => _AddSalaryPaymentSheetState();
}

class _AddSalaryPaymentSheetState extends State<AddSalaryPaymentSheet> {
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  PaymentType _type = PaymentType.salary;

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final amt = double.tryParse(_amountCtrl.text.trim()) ?? 0;
    if (amt <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Amount daalein')));
      return;
    }
    final appState = context.read<AppState>();
    final baki = appState.getMonthStats(widget.workerId, widget.year, widget.month).baki;

    if (amt > baki + 0.5) {
      final proceed = await showDialog<bool>(
        context: context,
        builder: (dctx) => AlertDialog(
          title: const Text('Baki Se Zyada Amount?'),
          content: Text('Current baki ${money(baki)} hai, lekin aap ${money(amt)} de rahe hain. Kya ye sahi hai?'),
          actions: [
            TextButton(onPressed: () => Navigator.of(dctx).pop(false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.of(dctx).pop(true), child: const Text('Haan, Sahi Hai')),
          ],
        ),
      );
      if (proceed != true) return;
    }

    appState.payments.add(
      Payment(
        id: newId(),
        workerId: widget.workerId,
        year: widget.year,
        month: widget.month,
        type: _type,
        amount: amt,
        date: DateFormat('yyyy-MM-dd').format(DateTime.now()),
        note: _noteCtrl.text.trim().isEmpty ? null : _noteCtrl.text.trim(),
        createdAt: DateTime.now().millisecondsSinceEpoch,
      ),
    );
    appState.scheduleSave();
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);
    final baki = appState.getMonthStats(widget.workerId, widget.year, widget.month).baki;

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Salary Payment Entry', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.text)),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: c.bgSoft, borderRadius: BorderRadius.circular(12)),
            child: Column(
              children: [
                Text('Current Baki', style: TextStyle(fontSize: 11.5, color: c.textFaint, fontWeight: FontWeight.w600)),
                const SizedBox(height: 3),
                Text(money(baki), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: c.text)),
              ],
            ),
          ),
          const SizedBox(height: 14),
          SegmentedButton<PaymentType>(
            segments: const [
              ButtonSegment(value: PaymentType.salary, label: Text('Salary')),
              ButtonSegment(value: PaymentType.advance, label: Text('Advance')),
            ],
            selected: {_type},
            onSelectionChanged: (s) => setState(() => _type = s.first),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _amountCtrl,
            decoration: const InputDecoration(labelText: 'Amount (₹)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            autofocus: true,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _noteCtrl,
            decoration: const InputDecoration(labelText: 'Note'),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
              ),
              const SizedBox(width: 12),
              Expanded(child: ElevatedButton(onPressed: _save, child: const Text('Save'))),
            ],
          ),
        ],
      ),
    );
  }
}
