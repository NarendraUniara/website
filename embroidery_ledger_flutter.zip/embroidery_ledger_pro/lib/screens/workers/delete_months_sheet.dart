import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/month_meta.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';

/// Mirrors renderDeleteMonthsModal()/confirmDeleteSelectedMonths(): pick one
/// or more of a worker's months and delete them in bulk (unlocking any
/// earlier month that had settled into a deleted one).
class DeleteMonthsSheet extends StatefulWidget {
  final String workerId;
  const DeleteMonthsSheet({super.key, required this.workerId});

  @override
  State<DeleteMonthsSheet> createState() => _DeleteMonthsSheetState();
}

class _DeleteMonthsSheetState extends State<DeleteMonthsSheet> {
  final Set<String> _selected = {};

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);
    final months = appState.getWorkerMonths(widget.workerId);

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 18,
        bottom: MediaQuery.of(context).viewInsets.bottom + 18,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Months Delete Karein', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: c.text)),
          if (months.isEmpty) ...[
            const SizedBox(height: 12),
            Text('Koi mahina nahi hai.', style: TextStyle(fontSize: 13.5, color: c.textDim)),
            const SizedBox(height: 16),
            OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Band Karein')),
          ] else ...[
            const SizedBox(height: 8),
            Text(
              'Jo mahine delete karne hain unhe select karein. Settled/locked mahina delete karne se agar wo pichle mahine se link tha to pichla mahina wapas unlock ho jayega.',
              style: TextStyle(fontSize: 12.5, color: c.textDim, height: 1.4),
            ),
            const SizedBox(height: 12),
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 320),
              child: ListView(
                shrinkWrap: true,
                children: months.map((mo) {
                  final key = '${mo.year}_${mo.month}';
                  final checked = _selected.contains(key);
                  final ms = appState.getMonthStats(widget.workerId, mo.year, mo.month);
                  return InkWell(
                    onTap: () => setState(() => checked ? _selected.remove(key) : _selected.add(key)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 9),
                      child: Row(
                        children: [
                          Icon(checked ? Icons.check_box : Icons.check_box_outline_blank,
                              color: checked ? c.accent : c.textFaint, size: 21),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Row(
                              children: [
                                Text(monthLabel(mo.year, mo.month),
                                    style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: c.text)),
                                if (ms.settled) ...[
                                  const SizedBox(width: 6),
                                  Text('— Settled', style: TextStyle(fontSize: 11.5, color: c.textFaint)),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: c.red),
                    onPressed: _selected.isEmpty ? null : () => _confirmDelete(context, appState),
                    child: const Text('Delete Karein'),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, AppState appState) {
    showDialog(
      context: context,
      builder: (dctx) => AlertDialog(
        title: const Text('Months Delete Karein?'),
        content: Text(
            '${_selected.length} mahine ki sab entries delete ho jayengi. Agar in mahino se pichla koi mahina lock tha to wo wapas unlock ho jayega.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dctx).pop(), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              for (final key in _selected) {
                final parts = key.split('_');
                final y = int.parse(parts[0]);
                final m = int.parse(parts[1]);
                appState.entries.removeWhere((e) => e.workerId == widget.workerId && e.year == y && e.month == m);
                appState.payments.removeWhere((p) => p.workerId == widget.workerId && p.year == y && p.month == m);
                appState.monthMeta.remove(monthMetaKey(widget.workerId, y, m));
                appState.unlockMonthsThatSettledInto(widget.workerId, y, m);
              }
              appState.scheduleSave();
              Navigator.of(dctx).pop();
              Navigator.of(context).pop();
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
