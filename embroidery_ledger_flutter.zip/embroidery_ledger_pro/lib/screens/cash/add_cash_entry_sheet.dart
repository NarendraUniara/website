import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../models/cash_entry.dart';
import '../../state/app_state.dart';

/// Mirrors openIEModal() / saveIE() / deleteIE() — add or edit a cash
/// book income/expense entry.
class AddCashEntrySheet extends StatefulWidget {
  final String? editEntryId;

  const AddCashEntrySheet({super.key, this.editEntryId});

  @override
  State<AddCashEntrySheet> createState() => _AddCashEntrySheetState();
}

class _AddCashEntrySheetState extends State<AddCashEntrySheet> {
  late CashEntryType _type;
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  String? _category;

  bool get _isEdit => widget.editEntryId != null;

  @override
  void initState() {
    super.initState();
    if (_isEdit) {
      final appState = context.read<AppState>();
      final e = appState.incomeExpense.firstWhere((e) => e.id == widget.editEntryId);
      _type = e.type;
      _amountCtrl.text = e.amount.toStringAsFixed(0);
      _noteCtrl.text = e.note ?? '';
      _category = e.category;
    } else {
      _type = CashEntryType.expense;
    }
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final amt = double.tryParse(_amountCtrl.text.trim()) ?? 0;
    if (amt <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Amount daalein')));
      return;
    }
    final appState = context.read<AppState>();
    final note = _noteCtrl.text.trim();

    if (_isEdit) {
      final idx = appState.incomeExpense.indexWhere((e) => e.id == widget.editEntryId);
      if (idx != -1) {
        final old = appState.incomeExpense[idx];
        appState.incomeExpense[idx] = CashEntry(
          id: old.id,
          type: _type,
          date: old.date,
          time: old.time,
          amount: amt,
          note: note,
          category: _category,
          createdAt: old.createdAt,
        );
      }
    } else {
      appState.incomeExpense.add(
        CashEntry(
          id: newId(),
          type: _type,
          date: DateFormat('yyyy-MM-dd').format(DateTime.now()),
          time: DateFormat('HH:mm').format(DateTime.now()),
          amount: amt,
          note: note,
          category: _category,
          createdAt: DateTime.now().millisecondsSinceEpoch,
        ),
      );
    }
    appState.scheduleSave();
    Navigator.of(context).pop();
  }

  void _delete() {
    final appState = context.read<AppState>();
    appState.incomeExpense.removeWhere((e) => e.id == widget.editEntryId);
    appState.scheduleSave();
    Navigator.of(context).pop();
  }

  Future<void> _promptNewCategory(AppState appState) async {
    final ctrl = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (dctx) => AlertDialog(
        title: const Text('Nayi Category'),
        content: TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(labelText: 'Naam')),
        actions: [
          TextButton(onPressed: () => Navigator.of(dctx).pop(), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(dctx).pop(ctrl.text.trim()), child: const Text('Add')),
        ],
      ),
    );
    if (name != null && name.isNotEmpty) {
      appState.addCashCategory(name, _type == CashEntryType.income);
      setState(() => _category = name);
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final categories =
        _type == CashEntryType.income ? appState.getIncomeCategories() : appState.getCategories();

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(_isEdit ? 'Entry Edit Karein' : 'Nayi Cash Entry',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          SegmentedButton<CashEntryType>(
            segments: const [
              ButtonSegment(value: CashEntryType.income, label: Text('Income')),
              ButtonSegment(value: CashEntryType.expense, label: Text('Expense')),
            ],
            selected: {_type},
            onSelectionChanged: (s) => setState(() {
              _type = s.first;
              _category = null;
            }),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _amountCtrl,
            decoration: const InputDecoration(labelText: 'Amount (₹)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            autofocus: true,
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _noteCtrl,
            decoration: const InputDecoration(labelText: 'Note'),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ...categories.map((c) {
                final selected = _category == c;
                return ChoiceChip(
                  label: Text(c),
                  selected: selected,
                  onSelected: (_) => setState(() => _category = selected ? null : c),
                );
              }),
              ActionChip(
                avatar: const Icon(Icons.add, size: 16),
                label: const Text('Naya'),
                onPressed: () => _promptNewCategory(appState),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: ElevatedButton(onPressed: _save, child: const Text('Save'))),
            ],
          ),
          if (_isEdit) ...[
            const SizedBox(height: 12),
            TextButton(
              onPressed: _delete,
              child: const Text('Entry Delete Karein', style: TextStyle(color: Colors.red)),
            ),
          ],
        ],
      ),
    );
  }
}
