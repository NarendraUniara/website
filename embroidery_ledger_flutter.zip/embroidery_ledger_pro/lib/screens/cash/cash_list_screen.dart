import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/cash_entry.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';
import 'add_cash_entry_sheet.dart';

enum _RangeMode { month, m3, m6, y1, custom }

/// Mirrors viewCashList(): range chips (this month / 3m / 6m / 1y / custom),
/// a month navigator, income/expense hero cards, net balance, and a
/// date-grouped transaction list.
class CashListScreen extends StatefulWidget {
  const CashListScreen({super.key});

  @override
  State<CashListScreen> createState() => _CashListScreenState();
}

class _CashListScreenState extends State<CashListScreen> {
  late int _year;
  late int _month;
  _RangeMode _mode = _RangeMode.month;
  DateTime? _customFrom;
  DateTime? _customTo;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _year = now.year;
    _month = now.month;
  }

  void _shiftMonth(int dir) {
    setState(() {
      var m = _month + dir;
      if (m < 1) {
        m = 12;
        _year--;
      } else if (m > 12) {
        m = 1;
        _year++;
      }
      _month = m;
    });
  }

  ({DateTime from, DateTime to}) _rangeBounds() {
    final today = DateTime.now();
    if (_mode == _RangeMode.custom) {
      return (from: _customFrom ?? today, to: _customTo ?? today);
    }
    final monthsBack = _mode == _RangeMode.m3 ? 3 : (_mode == _RangeMode.m6 ? 6 : 12);
    final from = DateTime(today.year, today.month - monthsBack + 1, 1);
    return (from: from, to: today);
  }

  String _fmtShort(DateTime d) => '${d.day} ${monthAbbrOf(d.month)[0]}${monthAbbrOf(d.month).substring(1).toLowerCase()} ${d.year}';

  Future<void> _pickCustomRange() async {
    final now = DateTime.now();
    final range = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 5),
      lastDate: now,
      initialDateRange: DateTimeRange(
        start: _customFrom ?? now.subtract(const Duration(days: 30)),
        end: _customTo ?? now,
      ),
    );
    if (range != null) {
      setState(() {
        _customFrom = range.start;
        _customTo = range.end;
        _mode = _RangeMode.custom;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);

    List<CashEntry> entries;
    String rangeTitle;
    if (_mode == _RangeMode.month) {
      entries = appState.incomeExpense.where((e) {
        final parts = e.date.split('-');
        if (parts.length < 2) return false;
        return int.tryParse(parts[0]) == _year && int.tryParse(parts[1]) == _month;
      }).toList();
      rangeTitle = monthLabel(_year, _month);
    } else {
      final b = _rangeBounds();
      final fromStr = '${b.from.year}-${b.from.month.toString().padLeft(2, '0')}-${b.from.day.toString().padLeft(2, '0')}';
      final toStr = '${b.to.year}-${b.to.month.toString().padLeft(2, '0')}-${b.to.day.toString().padLeft(2, '0')}';
      entries = appState.incomeExpense.where((e) => e.date.compareTo(fromStr) >= 0 && e.date.compareTo(toStr) <= 0).toList();
      rangeTitle = '${_fmtShort(b.from)} – ${_fmtShort(b.to)}';
    }
    entries.sort((a, b) => b.createdAt.compareTo(a.createdAt));

    final income = entries.where((e) => e.type == CashEntryType.income).fold<double>(0, (s, e) => s + e.amount);
    final expense = entries.where((e) => e.type == CashEntryType.expense).fold<double>(0, (s, e) => s + e.amount);

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            const TopbarTitle(title: 'Daily Cash', subtitle: 'Income & expense tracker'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: [
                _rangeChip('This Month', _RangeMode.month),
                _rangeChip('3M', _RangeMode.m3),
                _rangeChip('6M', _RangeMode.m6),
                _rangeChip('1Y', _RangeMode.y1),
                _rangeChip('Custom', _RangeMode.custom, onSelect: _pickCustomRange),
              ],
            ),
            const SizedBox(height: 10),
            if (_mode == _RangeMode.month)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _shiftMonth(-1)),
                  Text(rangeTitle, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: c.text)),
                  IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _shiftMonth(1)),
                ],
              )
            else
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(rangeTitle,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: c.text)),
              ),
            const SizedBox(height: 6),
            HeroRow(cards: [
              HeroCard(label: 'Income', amount: money(income)),
              HeroCard(label: 'Expense', amount: money(expense), isRed: true),
            ]),
            const SizedBox(height: 10),
            AppCard(
              child: Column(
                children: [
                  Text('Net Balance', style: TextStyle(fontSize: 11.5, color: c.textFaint, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 3),
                  Text(money(income - expense),
                      style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          color: (income - expense) >= 0 ? c.green : c.red)),
                ],
              ),
            ),
            SectionHead(
              title: 'Transactions',
              onAdd: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                builder: (_) => const AddCashEntrySheet(),
              ),
            ),
            if (entries.isEmpty)
              const EmptyState(emoji: '🧾', title: 'Koi entry nahi hai', subtitle: '+ dabakar income/expense add karein')
            else ...[
              ..._buildGroupedList(entries, c),
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Center(
                  child: Text('Total Entries: ${entries.length}',
                      style: TextStyle(fontSize: 12, color: c.textDim, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _rangeChip(String label, _RangeMode mode, {VoidCallback? onSelect}) {
    final selected = _mode == mode;
    final c = appColors(context);
    return InkWell(
      onTap: onSelect ?? () => setState(() => _mode = mode),
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? c.accent : c.bgSoft,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(label,
            style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.w700, color: selected ? Colors.white : c.textDim)),
      ),
    );
  }

  List<Widget> _buildGroupedList(List<CashEntry> entries, AppColors c) {
    final widgets = <Widget>[];
    String? lastDate;
    for (final e in entries) {
      if (e.date != lastDate) {
        final d = DateTime.tryParse(e.date);
        widgets.add(Padding(
          padding: const EdgeInsets.only(top: 10, bottom: 6),
          child: Text(
            d != null ? '${d.day} ${monthNames[d.month - 1].substring(0, 3)} ${d.year}' : e.date,
            style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: c.textFaint),
          ),
        ));
        lastDate = e.date;
      }
      final isIncome = e.type == CashEntryType.income;
      widgets.add(AppCard(
        onTap: () => showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          builder: (_) => AddCashEntrySheet(editEntryId: e.id),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(e.note?.isNotEmpty == true ? e.note! : (isIncome ? 'Income' : 'Expense'),
                      style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: c.text)),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Text(e.time, style: TextStyle(fontSize: 11.5, color: c.textFaint)),
                      if (e.category != null) ...[
                        const SizedBox(width: 6),
                        StatusBadge(e.category!, tone: BadgeTone.blue),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            Text('${isIncome ? '+' : '-'}${money(e.amount)}',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: isIncome ? c.green : c.red)),
          ],
        ),
      ));
    }
    return widgets;
  }
}
