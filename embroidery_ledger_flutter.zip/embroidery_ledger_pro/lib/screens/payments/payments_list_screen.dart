import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/worker.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';
import '../workers/month_detail_screen.dart';

/// Mirrors viewPaymentsList(): all-time total hero, a month navigator, this
/// month's total + carried-to-next-month hero row, and one card per worker
/// who had activity in the selected month (advance/salary/status badges).
class PaymentsListScreen extends StatefulWidget {
  const PaymentsListScreen({super.key});

  @override
  State<PaymentsListScreen> createState() => _PaymentsListScreenState();
}

class _PaymentsListScreenState extends State<PaymentsListScreen> {
  late int _year;
  late int _month;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _year = now.year;
    _month = now.month;
  }

  void _shift(int dir) {
    setState(() {
      var m = _month + dir;
      if (m < 1) {
        m = 12;
        _year--;
      } else if (m > 12) {
        m = 1;
        _year++;
      }
      _month = m;
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);

    final rows = <({Worker worker, int year, int month, MonthStats stats})>[];
    for (final w in appState.workers) {
      for (final mo in appState.getWorkerMonths(w.id)) {
        if (mo.year != _year || mo.month != _month) continue;
        final s = appState.getMonthStats(w.id, mo.year, mo.month);
        if (s.entries.isNotEmpty || s.totalAdvance > 0 || s.salaryPaid > 0) {
          rows.add((worker: w, year: mo.year, month: mo.month, stats: s));
        }
      }
    }
    rows.sort((a, b) => a.worker.name.compareTo(b.worker.name));

    final totalMonth = rows.fold<double>(0, (s, r) => s + r.stats.totalPaid);
    double totalAllTime = 0;
    for (final w in appState.workers) {
      for (final mo in appState.getWorkerMonths(w.id)) {
        totalAllTime += appState.getMonthStats(w.id, mo.year, mo.month).totalPaid;
      }
    }
    double carriedNext = 0;
    for (final r in rows) {
      if (r.stats.settled) carriedNext += r.stats.baki;
    }

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            const TopbarTitle(title: 'Payments', subtitle: 'Monthly payment record'),
            const SizedBox(height: 14),
            HeroCard(label: 'Total Payment (All Time)', amount: money(totalAllTime)),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => _shift(-1)),
                Text(monthLabel(_year, _month), style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: c.text)),
                IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => _shift(1)),
              ],
            ),
            HeroRow(cards: [
              HeroCard(label: 'Total Paid (${monthLabel(_year, _month)})', amount: money(totalMonth), compact: true),
              HeroCard(label: 'Carried → Next Month', amount: money(carriedNext), compact: true),
            ]),
            const SectionHead(title: 'Monthly Records'),
            if (rows.isEmpty)
              const EmptyState(emoji: '💳', title: 'Koi payment nahi hai', subtitle: 'Is mahine abhi tak koi payment nahi hui')
            else
              ...rows.map((r) {
                final st = r.stats;
                Widget statusBadge;
                if (st.settled) {
                  statusBadge = st.baki.abs() > 0.5
                      ? StatusBadge('Carried ${money(st.baki.abs())}', tone: BadgeTone.amber)
                      : const StatusBadge('Settled ✓', tone: BadgeTone.green);
                } else if (st.baki > 0.5) {
                  statusBadge = StatusBadge('Baki ${money(st.baki)}', tone: BadgeTone.amber);
                } else {
                  statusBadge = const SizedBox.shrink();
                }
                return AppCard(
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => MonthDetailScreen(workerId: r.worker.id, year: r.year, month: r.month),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(r.worker.name,
                                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: c.text)),
                              const SizedBox(height: 2),
                              Text(monthLabel(r.year, r.month), style: TextStyle(fontSize: 12.5, color: c.textDim)),
                            ],
                          ),
                          Text(money(st.totalPaid),
                              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: c.green)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Wrap(spacing: 6, runSpacing: 6, children: [
                        StatusBadge('Adv ${money(st.totalAdvance)}'),
                        StatusBadge('Salary ${money(st.salaryPaid)}'),
                        if (statusBadge is! SizedBox) statusBadge,
                      ]),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}
