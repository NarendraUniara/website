import 'package:flutter/material.dart';

import 'workers/workers_list_screen.dart';
import 'payments/payments_list_screen.dart';
import 'cash/cash_list_screen.dart';
import 'khata/accounts_list_screen.dart';

/// Mirrors currentTab / tabRoot() / renderNav() from the web app: four tabs,
/// each with its own navigation stack (so back-navigation within a tab
/// doesn't affect the others) — matches Navigator's per-tab offstage pattern.
class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _currentTab = 0;

  final List<GlobalKey<NavigatorState>> _navKeys = [
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
  ];

  static const _tabs = [
    _TabDef(icon: Icons.people_outline, label: 'Workers'),
    _TabDef(icon: Icons.credit_card_outlined, label: 'Payments'),
    _TabDef(icon: Icons.account_balance_wallet_outlined, label: 'Cash'),
    _TabDef(icon: Icons.menu_book_outlined, label: 'Khata'),
  ];

  Widget _buildTabNavigator(int index, Widget root) {
    return Navigator(
      key: _navKeys[index],
      onGenerateRoute: (settings) => MaterialPageRoute(builder: (_) => root),
    );
  }

  void _onTabTapped(int index) {
    if (index == _currentTab) {
      // Tapping the active tab again pops that tab's stack to root,
      // matching switchTab() resetting viewStack.
      _navKeys[index].currentState?.popUntil((r) => r.isFirst);
    } else {
      setState(() => _currentTab = index);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final nav = _navKeys[_currentTab].currentState!;
        if (nav.canPop()) {
          nav.pop();
          return false;
        }
        return true;
      },
      child: Scaffold(
        body: IndexedStack(
          index: _currentTab,
          children: [
            _buildTabNavigator(0, const WorkersListScreen()),
            _buildTabNavigator(1, const PaymentsListScreen()),
            _buildTabNavigator(2, const CashListScreen()),
            _buildTabNavigator(3, const AccountsListScreen()),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: _currentTab,
          onTap: _onTabTapped,
          items: _tabs
              .map((t) => BottomNavigationBarItem(icon: Icon(t.icon), label: t.label))
              .toList(),
        ),
      ),
    );
  }
}

class _TabDef {
  final IconData icon;
  final String label;
  const _TabDef({required this.icon, required this.label});
}
