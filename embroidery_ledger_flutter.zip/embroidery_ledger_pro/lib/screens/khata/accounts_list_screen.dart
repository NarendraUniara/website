import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/account.dart';
import '../../state/app_state.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';
import 'account_detail_screen.dart';
import 'add_account_sheet.dart';

/// Mirrors viewAccountsList(): to-receive/to-pay hero cards, then a list of
/// customer/supplier accounts with their running balance (with an optional
/// type filter chip row on top of the web app's plain list).
class AccountsListScreen extends StatefulWidget {
  const AccountsListScreen({super.key});

  @override
  State<AccountsListScreen> createState() => _AccountsListScreenState();
}

class _AccountsListScreenState extends State<AccountsListScreen> {
  AccountType? _filter; // null = all

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);
    var accounts = appState.accounts;
    if (_filter != null) {
      accounts = accounts.where((a) => a.type == _filter).toList();
    }

    double toReceive = 0, toPay = 0;
    for (final a in appState.accounts) {
      final bal = a.balance;
      if (bal > 0) {
        if (a.isCustomer) {
          toReceive += bal;
        } else {
          toPay += bal;
        }
      }
    }

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Expanded(
                  child: TopbarTitle(title: 'Khata', subtitle: 'Customer & Supplier Accounts'),
                ),
                HeadPlusButton(
                  onTap: () => showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    builder: (_) => const AddAccountSheet(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            HeroRow(cards: [
              HeroCard(label: 'To Receive', amount: money(toReceive)),
              HeroCard(label: 'To Pay', amount: money(toPay), isRed: true),
            ]),
            const SizedBox(height: 12),
            Row(
              children: [
                _FilterChip(label: 'Sabhi', selected: _filter == null, onTap: () => setState(() => _filter = null)),
                const SizedBox(width: 8),
                _FilterChip(
                  label: 'Customers',
                  selected: _filter == AccountType.customer,
                  onTap: () => setState(() => _filter = AccountType.customer),
                ),
                const SizedBox(width: 8),
                _FilterChip(
                  label: 'Suppliers',
                  selected: _filter == AccountType.supplier,
                  onTap: () => setState(() => _filter = AccountType.supplier),
                ),
              ],
            ),
            const SectionHead(title: 'Accounts'),
            if (accounts.isEmpty)
              const EmptyState(emoji: '📒', title: 'Koi account nahi hai', subtitle: '+ dabakar naya account banayein')
            else
              ...accounts.map((a) {
                final bal = a.balance;
                final isClear = bal <= 0.5;
                return ListRowCard(
                  leading: AppAvatar(name: a.name),
                  title: a.name,
                  subtitle: a.isCustomer ? 'Customer' : 'Supplier',
                  badges: [
                    StatusBadge(a.isCustomer ? 'To Receive' : 'To Pay', tone: a.isCustomer ? BadgeTone.blue : BadgeTone.red),
                    StatusBadge(isClear ? 'Clear ✓' : 'Baki ${money(bal)}', tone: isClear ? BadgeTone.green : BadgeTone.amber),
                  ],
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => AccountDetailScreen(accountId: a.id)),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = appColors(context);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
        decoration: BoxDecoration(color: selected ? c.accent : c.bgSoft, borderRadius: BorderRadius.circular(20)),
        child: Text(label,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: selected ? Colors.white : c.textDim)),
      ),
    );
  }
}
