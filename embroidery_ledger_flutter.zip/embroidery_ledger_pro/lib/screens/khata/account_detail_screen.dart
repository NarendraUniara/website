import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/account.dart';
import '../../models/khata_transaction.dart';
import '../../state/app_state.dart';
import '../../services/pdf_service.dart';
import '../../utils/app_theme.dart';
import '../../utils/format.dart';
import '../../widgets/app_widgets.dart';
import 'add_transaction_sheet.dart';

/// Mirrors viewAccountDetail(): total maal/paisa stat grid, baki summary,
/// and a transaction history list (with PDF export/share actions).
class AccountDetailScreen extends StatelessWidget {
  final String accountId;

  const AccountDetailScreen({super.key, required this.accountId});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final c = appColors(context);
    final account = appState.accounts.where((a) => a.id == accountId).firstOrNull;

    if (account == null) {
      return const Scaffold(body: Center(child: Text('Account not found')));
    }

    final bal = account.balance;
    final isClear = bal <= 0.5;
    final isCust = account.isCustomer;

    double totalBill = 0, totalPaid = 0;
    for (final t in account.transactions) {
      if (t.txType == TxType.bill) totalBill += t.amount;
      if (t.txType == TxType.payment || (t.txType == TxType.bill && t.billStatus == BillStatus.paid)) {
        totalPaid += t.amount;
      }
    }

    final sorted = [...account.transactions]..sort((a, b) => b.createdAt.compareTo(a.createdAt));

    return Scaffold(
      appBar: AppBar(
        title: Text(account.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf_outlined),
            tooltip: 'PDF banao',
            onPressed: () async => PdfService().exportAccountPdf(account),
          ),
          IconButton(
            icon: const Icon(Icons.share_outlined),
            tooltip: 'Share karo',
            onPressed: () async => PdfService().shareAccountPdf(account),
          ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () => _openAccountMenu(context, appState, account),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          Text(isCust ? 'Customer' : 'Supplier', style: TextStyle(color: c.textDim, fontWeight: FontWeight.w600)),
          if (account.contact?.isNotEmpty == true) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.call_outlined, size: 13, color: c.accent),
                const SizedBox(width: 4),
                Text(account.contact!, style: TextStyle(color: c.accent, fontSize: 12.5, fontWeight: FontWeight.w600)),
              ],
            ),
          ],
          const SizedBox(height: 10),
          AppCard(
            child: Column(
              children: [
                StatGrid(cells: [
                  StatCell(label: 'Total Maal', value: money(totalBill)),
                  StatCell(
                    label: 'Pesa ${isCust ? 'Aaya' : 'Diya'}',
                    value: money(totalPaid),
                  ),
                ]),
                Divider(color: c.border, height: 22),
                Text(isClear ? 'Baki / Udhar' : (isCust ? 'Baki Aana Hai' : 'Baki Dena Hai'),
                    style: TextStyle(fontSize: 11.5, color: c.textFaint, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text(
                  isClear ? 'Clear ✓' : money(bal),
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    color: isClear ? c.green : (isCust ? c.green : c.red),
                  ),
                ),
              ],
            ),
          ),
          SectionHead(
            title: 'Transactions',
            onAdd: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (_) => AddTransactionSheet(accountId: account.id),
            ),
          ),
          if (sorted.isEmpty)
            const EmptyState(emoji: '🧾', title: 'Koi entry nahi hai', subtitle: '+ dabakar bill ya payment add karein')
          else ...[
            ...sorted.map((t) {
              final isGreen = t.txType == TxType.bill ? !isCust : isCust;
              final title = t.txType == TxType.bill ? (isCust ? 'Maal Diya' : 'Maal Liya') : (isCust ? 'Pesa Aaya' : 'Pesa Diya');
              final d = DateTime.tryParse(t.date);
              return AppCard(
                onTap: () => showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  builder: (_) => AddTransactionSheet(accountId: account.id, editTransactionId: t.id),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(t.note?.isNotEmpty == true ? t.note! : title,
                              style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: c.text)),
                          const SizedBox(height: 5),
                          Wrap(spacing: 6, runSpacing: 4, children: [
                            StatusBadge(title, tone: isGreen ? BadgeTone.green : BadgeTone.red),
                            if (t.payMode != null)
                              StatusBadge(t.payMode == PayMode.online ? 'Online' : 'Cash', tone: BadgeTone.blue),
                            if (t.category?.isNotEmpty == true) StatusBadge(t.category!),
                          ]),
                          const SizedBox(height: 4),
                          Text(
                            d != null ? '${d.day} ${monthNames[d.month - 1].substring(0, 3)} · ${t.time}' : t.time,
                            style: TextStyle(fontSize: 11, color: c.textFaint),
                          ),
                        ],
                      ),
                    ),
                    Text('${isGreen ? '+' : '-'}${money(t.amount)}',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: isGreen ? c.green : c.red)),
                  ],
                ),
              );
            }),
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Center(
                child: Text('Total Entries: ${sorted.length}',
                    style: TextStyle(fontSize: 12, color: c.textDim, fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ],
      ),
    );
  }

  void _openAccountMenu(BuildContext context, AppState appState, Account account) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.badge_outlined),
              title: const Text('Naam Edit Karein'),
              onTap: () {
                Navigator.of(ctx).pop();
                _editField(context, appState, account, isName: true);
              },
            ),
            ListTile(
              leading: const Icon(Icons.call_outlined),
              title: const Text('Contact Edit Karein'),
              onTap: () {
                Navigator.of(ctx).pop();
                _editField(context, appState, account, isName: false);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline, color: Colors.red),
              title: const Text('Account Delete Karein', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.of(ctx).pop();
                showDialog(
                  context: context,
                  builder: (dctx) => AlertDialog(
                    title: const Text('Account Delete Karein?'),
                    content: const Text('Sab transactions delete ho jayengi.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.of(dctx).pop(), child: const Text('Cancel')),
                      TextButton(
                        onPressed: () {
                          appState.deleteAccount(account.id);
                          Navigator.of(dctx).pop();
                          Navigator.of(context).pop();
                        },
                        child: const Text('Delete', style: TextStyle(color: Colors.red)),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _editField(BuildContext context, AppState appState, Account account, {required bool isName}) async {
    final ctrl = TextEditingController(text: isName ? account.name : (account.contact ?? ''));
    final value = await showDialog<String>(
      context: context,
      builder: (dctx) => AlertDialog(
        title: Text(isName ? 'Naam Edit Karein' : 'Contact Edit Karein'),
        content: TextField(controller: ctrl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.of(dctx).pop(), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(dctx).pop(ctrl.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    if (value == null) return;
    if (isName) {
      if (value.isEmpty) return;
      account.name = value;
    } else {
      account.contact = value.isEmpty ? null : value;
    }
    appState.scheduleSave();
  }
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
