import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../models/khata_transaction.dart';
import '../../state/app_state.dart';

/// Mirrors openAddTxModal() / openEditTxModal() / renderAddTxModal() /
/// saveNewTx() / confirmDeleteTx() — add or edit a bill/payment entry
/// under a khata account.
class AddTransactionSheet extends StatefulWidget {
  final String accountId;
  final String? editTransactionId;

  const AddTransactionSheet({
    super.key,
    required this.accountId,
    this.editTransactionId,
  });

  @override
  State<AddTransactionSheet> createState() => _AddTransactionSheetState();
}

class _AddTransactionSheetState extends State<AddTransactionSheet> {
  late TxType _txType;
  late PayMode _payMode;
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  String? _category;

  bool get _isEdit => widget.editTransactionId != null;

  @override
  void initState() {
    super.initState();
    final appState = context.read<AppState>();
    final account = appState.accounts.firstWhere((a) => a.id == widget.accountId);

    if (_isEdit) {
      final tx = account.transactions.firstWhere((t) => t.id == widget.editTransactionId);
      _txType = tx.txType;
      _payMode = tx.payMode ?? PayMode.cash;
      _amountCtrl.text = tx.amount.toStringAsFixed(0);
      _noteCtrl.text = tx.note ?? '';
      _category = tx.category;
    } else {
      _txType = TxType.bill;
      _payMode = PayMode.cash;
    }
  }

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final amt = double.tryParse(_amountCtrl.text.trim()) ?? 0;
    if (amt <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Amount daalein')));
      return;
    }

    final appState = context.read<AppState>();
    final account = appState.accounts.firstWhere((a) => a.id == widget.accountId);
    final note = _noteCtrl.text.trim();

    if (_isEdit) {
      final idx = account.transactions.indexWhere((t) => t.id == widget.editTransactionId);
      if (idx != -1) {
        final old = account.transactions[idx];
        account.transactions[idx] = KhataTransaction(
          id: old.id,
          txType: _txType,
          billStatus: _txType == TxType.bill ? (old.billStatus ?? BillStatus.unpaid) : null,
          payMode: _txType == TxType.payment ? _payMode : null,
          amount: amt,
          date: old.date,
          time: old.time,
          note: note,
          category: _category,
          createdAt: old.createdAt,
        );
      }
    } else {
      account.transactions.add(
        KhataTransaction(
          id: newId(),
          txType: _txType,
          billStatus: _txType == TxType.bill ? BillStatus.unpaid : null,
          payMode: _txType == TxType.payment ? _payMode : null,
          amount: amt,
          date: DateFormat('yyyy-MM-dd').format(DateTime.now()),
          time: DateFormat('HH:mm').format(DateTime.now()),
          note: note,
          category: _category,
          createdAt: DateTime.now().millisecondsSinceEpoch,
        ),
      );
    }
    appState.scheduleSave();
    Navigator.of(context).pop();
  }

  void _delete() {
    final appState = context.read<AppState>();
    final account = appState.accounts.firstWhere((a) => a.id == widget.accountId);
    account.transactions.removeWhere((t) => t.id == widget.editTransactionId);
    appState.scheduleSave();
    Navigator.of(context).pop();
  }

  Future<void> _promptNewCategory(AppState appState) async {
    final ctrl = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (dctx) => AlertDialog(
        title: const Text('Nayi Category'),
        content: TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(labelText: 'Naam')),
        actions: [
          TextButton(onPressed: () => Navigator.of(dctx).pop(), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.of(dctx).pop(ctrl.text.trim()), child: const Text('Add')),
        ],
      ),
    );
    if (name != null && name.isNotEmpty) {
      appState.addTxCategory(name);
      setState(() => _category = name);
    }
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final account = appState.accounts.firstWhere((a) => a.id == widget.accountId);
    final isCust = account.isCustomer;

    final billLabel = isCust ? 'Maal Diya' : 'Maal Liya';
    final paymentLabel = isCust ? 'Pesa Aaya' : 'Pesa Diya';

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(_isEdit ? 'Entry Edit Karein' : 'Nayi Entry Karein',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          SegmentedButton<TxType>(
            segments: [
              ButtonSegment(value: TxType.bill, label: Text(billLabel)),
              ButtonSegment(value: TxType.payment, label: Text(paymentLabel)),
            ],
            selected: {_txType},
            onSelectionChanged: (s) => setState(() => _txType = s.first),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _amountCtrl,
            decoration: const InputDecoration(labelText: 'Amount (₹)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            autofocus: true,
          ),
          if (_txType == TxType.payment) ...[
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Payment Mode'),
                SegmentedButton<PayMode>(
                  segments: const [
                    ButtonSegment(value: PayMode.cash, label: Text('Cash')),
                    ButtonSegment(value: PayMode.online, label: Text('Online')),
                  ],
                  selected: {_payMode},
                  onSelectionChanged: (s) => setState(() => _payMode = s.first),
                ),
              ],
            ),
          ],
          const SizedBox(height: 12),
          TextField(
            controller: _noteCtrl,
            decoration: const InputDecoration(labelText: 'Note'),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ...appState.getKhataCategories().map((c) {
                final selected = _category == c;
                return ChoiceChip(
                  label: Text(c),
                  selected: selected,
                  onSelected: (_) => setState(() => _category = selected ? null : c),
                );
              }),
              ActionChip(
                avatar: const Icon(Icons.add, size: 16),
                label: const Text('Naya'),
                onPressed: () => _promptNewCategory(appState),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(onPressed: _save, child: const Text('Save')),
              ),
            ],
          ),
          if (_isEdit) ...[
            const SizedBox(height: 12),
            TextButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('Entry Delete?'),
                    content: const Text('Ye transaction delete ho jayegi.'),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.of(context).pop(), child: const Text('Cancel')),
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                          _delete();
                        },
                        child: const Text('Delete', style: TextStyle(color: Colors.red)),
                      ),
                    ],
                  ),
                );
              },
              child: const Text('Entry Delete Karein', style: TextStyle(color: Colors.red)),
            ),
          ],
        ],
      ),
    );
  }
}
