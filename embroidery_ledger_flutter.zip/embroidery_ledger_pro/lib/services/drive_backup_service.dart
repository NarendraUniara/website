import 'dart:convert';

import 'package:http/http.dart' as http;

/// Mirrors findDriveBackupFile()/backupToDrive()/restoreFromDrive(): stores
/// a single JSON backup file in the app's hidden Drive "appDataFolder",
/// using the same raw REST calls as the web app's fetch()-based version
/// (rather than the heavier googleapis package).
class DriveBackupService {
  static const _fileName = 'embroidery-ledger-backup.json';
  static const _base = 'https://www.googleapis.com/drive/v3/files';
  static const _uploadBase = 'https://www.googleapis.com/upload/drive/v3/files';

  /// Mirrors driveErrorMessage(): turns a failed response into a readable message.
  Future<String> _errorMessage(http.Response res) async {
    String msg = '';
    try {
      final body = jsonDecode(res.body) as Map<String, dynamic>;
      msg = (body['error']?['message'] as String?) ?? '';
    } catch (_) {}
    if (res.statusCode == 401) return 'Drive session expire ho gayi';
    if (res.statusCode == 403 &&
        RegExp('disabled|has not been used|it is disabled', caseSensitive: false).hasMatch(msg)) {
      return 'Google Drive API GCP console me disabled hai';
    }
    if (res.statusCode == 403 && RegExp('insufficient|scope', caseSensitive: false).hasMatch(msg)) {
      return 'Drive permission (scope) nahi mili';
    }
    if (res.statusCode == 403) return 'Drive access forbidden';
    return 'Drive error (${res.statusCode})${msg.isNotEmpty ? ' — $msg' : ''}';
  }

  /// Mirrors findDriveBackupFile(): looks for the single backup file in appDataFolder.
  Future<({String id, String? modifiedTime})?> findBackupFile(String token) async {
    final q = Uri.encodeComponent("name='$_fileName' and trashed=false");
    final res = await http.get(
      Uri.parse('$_base?q=$q&spaces=appDataFolder&fields=files(id,name,modifiedTime)'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (res.statusCode != 200) {
      throw Exception(await _errorMessage(res));
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final files = data['files'] as List<dynamic>? ?? [];
    if (files.isEmpty) return null;
    final f = files.first as Map<String, dynamic>;
    return (id: f['id'] as String, modifiedTime: f['modifiedTime'] as String?);
  }

  /// Mirrors backupToDrive(): uploads (or updates) the JSON backup as a
  /// multipart/related request, exactly like the web app's raw fetch() body.
  Future<void> backupToDrive(String token, Map<String, dynamic> backupJson) async {
    final existing = await findBackupFile(token);
    final jsonStr = const JsonEncoder.withIndent('  ').convert(backupJson);
    final boundary = 'ledgerbackup${DateTime.now().millisecondsSinceEpoch}';
    final metadata = existing == null
        ? {'name': _fileName, 'mimeType': 'application/json', 'parents': ['appDataFolder']}
        : <String, dynamic>{};
    final body = '--$boundary\r\n'
        'Content-Type: application/json; charset=UTF-8\r\n\r\n'
        '${jsonEncode(metadata)}\r\n'
        '--$boundary\r\n'
        'Content-Type: application/json\r\n\r\n'
        '$jsonStr\r\n'
        '--$boundary--';

    final url = existing == null
        ? Uri.parse('$_uploadBase?uploadType=multipart')
        : Uri.parse('$_uploadBase/${existing.id}?uploadType=multipart');

    final res = await (existing == null
        ? http.post(url,
            headers: {'Authorization': 'Bearer $token', 'Content-Type': 'multipart/related; boundary=$boundary'},
            body: body)
        : http.patch(url,
            headers: {'Authorization': 'Bearer $token', 'Content-Type': 'multipart/related; boundary=$boundary'},
            body: body));

    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception(await _errorMessage(res));
    }
  }

  /// Mirrors restoreFromDrive()'s file download: fetches the backup file's raw content.
  Future<Map<String, dynamic>> downloadBackup(String token, String fileId) async {
    final res = await http.get(
      Uri.parse('$_base/$fileId?alt=media'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (res.statusCode != 200) {
      throw Exception(await _errorMessage(res));
    }
    return jsonDecode(res.body) as Map<String, dynamic>;
  }
}
