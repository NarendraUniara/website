import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../models/account.dart';
import '../models/khata_transaction.dart';
import '../models/worker.dart';
import '../models/shift_entry.dart';
import '../state/app_state.dart' show MonthStats;
import '../utils/format.dart';

/// Port of buildAccountPDF() / exportAccountPDF() / shareAccountPDF() AND
/// exportMonthPDF() / exportMonthPDFFallback() from the web app, using the
/// `pdf` + `printing` packages instead of jsPDF/autotable.
class PdfService {
  static const _brandBlue = PdfColor.fromInt(0xFF2563EB);
  static const _dimGray = PdfColor.fromInt(0xFF5A6478);
  static const _darkText = PdfColor.fromInt(0xFF141623);
  static const _stripeGray = PdfColor.fromInt(0xFFF2F5FA);

  String _money(double v) => 'Rs.${v.toStringAsFixed(2)}';

  String _todayIso() => DateFormat('yyyy-MM-dd').format(DateTime.now());

  /// Mirrors bakiStatusPlain(s) in the web app.
  String _bakiStatusPlain(MonthStats s) {
    if (s.settled) {
      return s.totalPaid > 0.5 ? 'Settled (${_money(s.totalPaid)})' : 'Settled';
    }
    return _money(s.baki);
  }

  Future<pw.Document> buildAccountPdf(Account account) async {
    final isCust = account.isCustomer;
    final bal = account.balance;

    double totalBill = 0;
    double totalPaid = 0;
    for (final t in account.transactions) {
      if (t.txType == TxType.bill) totalBill += t.amount;
      if (t.txType == TxType.payment ||
          (t.txType == TxType.bill && t.billStatus == BillStatus.paid)) {
        totalPaid += t.amount;
      }
    }

    final bakiLabel = bal <= 0.5 ? 'Clear' : (isCust ? 'Baki Aana Hai' : 'Baki Dena Hai');
    final bakiVal = bal <= 0.5 ? 'Rs.0.00' : _money(bal.abs());

    final sorted = [...account.transactions]
      ..sort((a, b) => a.createdAt.compareTo(b.createdAt));

    final rows = sorted.map((t) {
      final isGreen = t.txType == TxType.bill ? !isCust : isCust;
      final title = t.txType == TxType.bill
          ? (isCust ? 'Maal Diya' : 'Maal Liya')
          : (isCust ? 'Pesa Aaya' : 'Pesa Diya');
      final sign = isGreen ? '+' : '-';
      return [
        t.date.isEmpty ? '-' : t.date,
        title,
        t.note?.isNotEmpty == true ? t.note! : '-',
        t.category?.isNotEmpty == true ? t.category! : '-',
        '$sign${_money(t.amount)}',
      ];
    }).toList();

    final doc = pw.Document();

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(14 * PdfPageFormat.mm / 10 == 0 ? 14 : 14),
        header: (context) {
          if (context.pageNumber > 1) return pw.SizedBox();
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.fromLTRB(14, 10, 14, 10),
                color: _brandBlue,
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('Embroidery Ledger',
                        style: pw.TextStyle(
                            color: PdfColors.white,
                            fontSize: 16,
                            fontWeight: pw.FontWeight.bold)),
                    pw.SizedBox(height: 3),
                    pw.Text('Khata Statement',
                        style: const pw.TextStyle(color: PdfColors.white, fontSize: 10)),
                    pw.SizedBox(height: 3),
                    pw.Text('Generated: ${_todayIso()}',
                        style: const pw.TextStyle(color: PdfColors.white, fontSize: 9)),
                  ],
                ),
              ),
              pw.SizedBox(height: 12),
              pw.Text(account.name,
                  style: pw.TextStyle(
                      color: _darkText, fontSize: 14, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 4),
              pw.Text(
                [
                  isCust ? 'Customer' : 'Supplier',
                  if (account.contact?.isNotEmpty == true) account.contact!,
                ].join('   \u00b7   '),
                style: const pw.TextStyle(color: _dimGray, fontSize: 10),
              ),
              pw.SizedBox(height: 10),
              pw.Table(
                columnWidths: const {
                  0: pw.FlexColumnWidth(2),
                  1: pw.FlexColumnWidth(2.4),
                  2: pw.FlexColumnWidth(2),
                  3: pw.FlexColumnWidth(2.4),
                },
                children: [
                  pw.TableRow(children: [
                    _label('Total Maal'),
                    _value(_money(totalBill)),
                    _label(isCust ? 'Payment Received' : 'Payment Given'),
                    _value(_money(totalPaid)),
                  ]),
                  pw.TableRow(children: [
                    _label('Balance Status'),
                    _value(bakiLabel),
                    _label('Balance Amount'),
                    _value(bakiVal),
                  ]),
                ],
              ),
              pw.SizedBox(height: 6),
              pw.Divider(color: PdfColors.grey400, thickness: 0.6),
            ],
          );
        },
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerLeft,
          child: pw.Text(
            'Embroidery Ledger \u00b7 Page ${context.pageNumber} of ${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 8, color: PdfColor.fromInt(0xFF8C94A5)),
          ),
        ),
        build: (context) => [
          pw.TableHelper.fromTextArray(
            headers: const ['Date', 'Type', 'Note', 'Category', 'Amount'],
            data: rows,
            headerStyle: pw.TextStyle(
                color: PdfColors.white, fontWeight: pw.FontWeight.bold, fontSize: 9),
            headerDecoration: const pw.BoxDecoration(color: _brandBlue),
            cellStyle: const pw.TextStyle(fontSize: 8.8, color: _darkText),
            oddRowDecoration: const pw.BoxDecoration(color: _stripeGray),
            cellAlignments: {4: pw.Alignment.centerRight},
            columnWidths: const {
              0: pw.FlexColumnWidth(1.6),
              1: pw.FlexColumnWidth(1.8),
              2: pw.FlexColumnWidth(2.6),
              3: pw.FlexColumnWidth(1.8),
              4: pw.FlexColumnWidth(1.8),
            },
          ),
        ],
      ),
    );

    return doc;
  }

  pw.Widget _label(String text) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 2.4),
        child: pw.Text(text,
            style: pw.TextStyle(
                fontSize: 9.5, color: _dimGray, fontWeight: pw.FontWeight.bold)),
      );

  pw.Widget _value(String text) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 2.4),
        child: pw.Text(text,
            style: pw.TextStyle(
                fontSize: 9.5, color: _darkText, fontWeight: pw.FontWeight.bold)),
      );

  String fileNameFor(Account account) {
    final safeName = account.name.replaceAll(RegExp(r'\s+'), '_');
    return '$safeName-Khata-${_todayIso()}.pdf';
  }

  /// Mirrors exportAccountPDF(): saves/opens the PDF via the OS share/print sheet.
  Future<void> exportAccountPdf(Account account) async {
    final doc = await buildAccountPdf(account);
    await Printing.sharePdf(bytes: await doc.save(), filename: fileNameFor(account));
  }

  /// Mirrors shareAccountPDF(): opens the native share sheet with the PDF file.
  Future<void> shareAccountPdf(Account account) async {
    final doc = await buildAccountPdf(account);
    await Printing.sharePdf(bytes: await doc.save(), filename: fileNameFor(account));
  }

  // ---------------- Month / worker PDF ----------------

  /// Mirrors exportMonthPDF(): a branded header, a 4x2 summary grid, and a
  /// day-by-day table (Day / Mon / Shift / Stitches / Hours / Advance / Earning).
  Future<pw.Document> buildMonthPdf(Worker worker, MonthStats s, int year, int month) async {
    final summaryRows = [
      ['Working Days', '${s.workingDays}', 'Absent Days', '${s.absentDays}'],
      ['Total Stitches', numberIN(s.totalStitches), 'Total Hours', '${s.totalHours}'],
      ['Total Earned', _money(s.totalEarned), 'Advance', _money(s.totalAdvance)],
      ['Salary Paid', _money(s.salaryPaid), 'Baki', _bakiStatusPlain(s)],
    ];

    final tableRows = s.entries.map((e) {
      if (e.absent) {
        return [
          '${e.day}',
          monthAbbrOf(month),
          'Absent',
          '-',
          '-',
          '-',
          '-',
        ];
      }
      final sh = ShiftType.of(e.shift);
      final pay = e.stitches * e.rate;
      return [
        '${e.day}',
        monthAbbrOf(month),
        sh.en,
        numberIN(e.stitches),
        '${e.hours}',
        e.advance > 0 ? _money(e.advance) : '-',
        _money(pay),
      ];
    }).toList();

    final doc = pw.Document();

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(14),
        header: (context) {
          if (context.pageNumber > 1) {
            return pw.Text('${worker.name} \u00b7 ${monthLabel(year, month)}',
                style: pw.TextStyle(color: _darkText, fontSize: 10, fontWeight: pw.FontWeight.bold));
          }
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Container(
                width: double.infinity,
                padding: const pw.EdgeInsets.fromLTRB(14, 10, 14, 10),
                color: _brandBlue,
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text('Embroidery Ledger',
                        style: pw.TextStyle(color: PdfColors.white, fontSize: 16, fontWeight: pw.FontWeight.bold)),
                    pw.SizedBox(height: 3),
                    pw.Text('Monthly Hisab Report', style: const pw.TextStyle(color: PdfColors.white, fontSize: 10)),
                    pw.SizedBox(height: 3),
                    pw.Text('Generated: ${_todayIso()}', style: const pw.TextStyle(color: PdfColors.white, fontSize: 9)),
                  ],
                ),
              ),
              pw.SizedBox(height: 12),
              pw.Text(worker.name,
                  style: pw.TextStyle(color: _darkText, fontSize: 14, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 4),
              pw.Text('${monthLabel(year, month)}   \u00b7   Rate: Rs.${worker.rate} / stitch',
                  style: const pw.TextStyle(color: _dimGray, fontSize: 10)),
              pw.SizedBox(height: 10),
              pw.Table(
                columnWidths: const {
                  0: pw.FlexColumnWidth(2),
                  1: pw.FlexColumnWidth(2.4),
                  2: pw.FlexColumnWidth(2),
                  3: pw.FlexColumnWidth(2.4),
                },
                children: [
                  for (final row in summaryRows)
                    pw.TableRow(children: [
                      _label(row[0]),
                      _value(row[1]),
                      _label(row[2]),
                      _value(row[3]),
                    ]),
                ],
              ),
              pw.SizedBox(height: 6),
              pw.Divider(color: PdfColors.grey400, thickness: 0.6),
            ],
          );
        },
        footer: (context) => pw.Align(
          alignment: pw.Alignment.centerLeft,
          child: pw.Text(
            'Embroidery Ledger \u00b7 Page ${context.pageNumber} of ${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 8, color: PdfColor.fromInt(0xFF8C94A5)),
          ),
        ),
        build: (context) => [
          pw.TableHelper.fromTextArray(
            headers: const ['Day', 'Mon', 'Shift', 'Stitches', 'Hours', 'Advance', 'Earning'],
            data: tableRows,
            headerStyle: pw.TextStyle(color: PdfColors.white, fontWeight: pw.FontWeight.bold, fontSize: 9),
            headerDecoration: const pw.BoxDecoration(color: _brandBlue),
            cellStyle: const pw.TextStyle(fontSize: 8.8, color: _darkText),
            oddRowDecoration: const pw.BoxDecoration(color: _stripeGray),
            cellAlignments: {
              0: pw.Alignment.center,
              1: pw.Alignment.center,
              3: pw.Alignment.centerRight,
              4: pw.Alignment.centerRight,
              5: pw.Alignment.centerRight,
              6: pw.Alignment.centerRight,
            },
            columnWidths: const {
              0: pw.FlexColumnWidth(1),
              1: pw.FlexColumnWidth(1),
              2: pw.FlexColumnWidth(2),
              3: pw.FlexColumnWidth(1.8),
              4: pw.FlexColumnWidth(1.4),
              5: pw.FlexColumnWidth(1.8),
              6: pw.FlexColumnWidth(1.8),
            },
          ),
        ],
      ),
    );

    return doc;
  }

  String fileNameForMonth(Worker worker, int year, int month) {
    final safeName = worker.name.replaceAll(RegExp(r'\s+'), '_');
    return '$safeName-${monthNames[month - 1]}-$year.pdf';
  }

  /// Mirrors exportMonthPDF(): saves/opens the month's PDF via the OS share/print sheet.
  Future<void> exportMonthPdf(Worker worker, MonthStats stats, int year, int month) async {
    final doc = await buildMonthPdf(worker, stats, year, month);
    await Printing.sharePdf(bytes: await doc.save(), filename: fileNameForMonth(worker, year, month));
  }

  /// Mirrors sharing the month's PDF through the native share sheet.
  Future<void> shareMonthPdf(Worker worker, MonthStats stats, int year, int month) async {
    final doc = await buildMonthPdf(worker, stats, year, month);
    await Printing.sharePdf(bytes: await doc.save(), filename: fileNameForMonth(worker, year, month));
  }
}
