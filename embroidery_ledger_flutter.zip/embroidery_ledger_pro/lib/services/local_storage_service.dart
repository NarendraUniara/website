import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Mirrors the web app's `localStorage.setItem(STORAGE_KEY, JSON.stringify(state))`.
class LocalStorageService {
  static const _storageKey = 'embroidery_ledger_pro_v3';

  Future<Map<String, dynamic>?> loadState() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null) return null;
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  Future<void> saveState(Map<String, dynamic> state) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(state));
  }
}
