import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// Mirrors exportBackup() and the restoreFile <input type="file"> handler:
/// share a JSON snapshot of the ledger as a file, or pick+parse one back in.
class LocalBackupService {
  String _todayIso() {
    final d = DateTime.now();
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  /// Mirrors exportBackup(): writes a pretty-printed JSON file and opens the
  /// OS share sheet (the closest mobile equivalent of the web app's download).
  Future<void> exportBackup(Map<String, dynamic> backupJson) async {
    final jsonStr = const JsonEncoder.withIndent('  ').convert(backupJson);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/embroidery-ledger-backup-${_todayIso()}.json');
    await file.writeAsString(jsonStr);
    await Share.shareXFiles([XFile(file.path)], text: 'Embroidery Ledger Backup');
  }

  /// Mirrors the restoreFile onchange handler: lets the user pick a .json
  /// backup file and parses it. Returns null if the user cancels, and
  /// throws a FormatException if the file isn't valid JSON.
  Future<Map<String, dynamic>?> pickAndParseBackup() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return null;
    final bytes = result.files.first.bytes;
    if (bytes == null) return null;
    final text = utf8.decode(bytes);
    return jsonDecode(text) as Map<String, dynamic>;
  }
}
