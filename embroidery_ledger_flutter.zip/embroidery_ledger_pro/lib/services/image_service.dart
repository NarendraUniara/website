import 'dart:convert';
import 'dart:typed_data';

import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';

/// Mirrors compressImage()/handleWorkerPhotoPick(): picks a photo, resizes it
/// so its longest side is at most 360px, then re-encodes as JPEG at
/// decreasing quality until it's under a hard byte cap (the photo stays only
/// on this device — it's never synced — so we keep it small).
class ImageService {
  static const _maxDim = 360;
  static const _maxBytes = 100 * 1024; // 100KB hard cap, same as the web app

  final ImagePicker _picker = ImagePicker();

  /// Opens the gallery, then compresses the chosen photo.
  /// Returns a `data:image/jpeg;base64,...` string, or null if cancelled/failed.
  Future<String?> pickAndCompressWorkerPhoto() async {
    final XFile? file = await _picker.pickImage(source: ImageSource.gallery);
    if (file == null) return null;
    final bytes = await file.readAsBytes();
    return compress(bytes);
  }

  /// Resizes+re-encodes raw image bytes into a small base64 JPEG data URL.
  String? compress(Uint8List bytes) {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) return null;

    var w = decoded.width;
    var h = decoded.height;
    if (w > _maxDim || h > _maxDim) {
      if (w >= h) {
        h = (h * _maxDim / w).round();
        w = _maxDim;
      } else {
        w = (w * _maxDim / h).round();
        h = _maxDim;
      }
    }

    var resized = img.copyResize(decoded, width: w, height: h, interpolation: img.Interpolation.average);
    var quality = 80;
    var out = img.encodeJpg(resized, quality: quality);
    while (out.lengthInBytes > _maxBytes && quality > 30) {
      quality -= 10;
      out = img.encodeJpg(resized, quality: quality);
    }
    var tries = 0;
    while (out.lengthInBytes > _maxBytes && tries < 5) {
      w = (w * 0.8).round();
      h = (h * 0.8).round();
      resized = img.copyResize(decoded, width: w, height: h, interpolation: img.Interpolation.average);
      out = img.encodeJpg(resized, quality: quality);
      tries++;
    }

    return 'data:image/jpeg;base64,${base64Encode(out)}';
  }
}
