import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/worker.dart';
import '../models/shift_entry.dart';
import '../models/payment.dart';
import '../models/month_meta.dart';

/// Mirrors syncWorkerToFirestore() / removeWorkerFromFirestore() / the
/// "shared khata" read path in the web app — one document per shared
/// worker, keyed by the email it's shared to.
class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  DocumentReference<Map<String, dynamic>> _sharedDoc(String email) =>
      _db.collection('sharedLedgers').doc(email);

  Future<void> syncWorker(
    Worker worker,
    List<ShiftEntry> allEntries,
    List<Payment> allPayments,
    Map<String, MonthMeta> allMonthMeta,
  ) async {
    if (worker.shareEmail == null || !worker.shareOn) return;

    final workerEntries = allEntries.where((e) => e.workerId == worker.id).toList();
    final workerPayments = allPayments.where((p) => p.workerId == worker.id).toList();
    final workerMeta = Map.fromEntries(
      allMonthMeta.entries.where((e) => e.key.startsWith('${worker.id}_')),
    );

    await _sharedDoc(worker.shareEmail!).set({
      'worker': worker.toJson(),
      'entries': workerEntries.map((e) => e.toJson()).toList(),
      'payments': workerPayments.map((p) => p.toJson()).toList(),
      'monthMeta': workerMeta.map((k, v) => MapEntry(k, v.toJson())),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> removeWorker(String email) async {
    await _sharedDoc(email).delete();
  }

  Future<Map<String, dynamic>?> fetchSharedForEmail(String email) async {
    final snap = await _sharedDoc(email).get();
    return snap.data();
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> watchSharedForEmail(String email) =>
      _sharedDoc(email).snapshots();
}
