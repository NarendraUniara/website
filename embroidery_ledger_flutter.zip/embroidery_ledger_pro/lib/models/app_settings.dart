class AppSettings {
  String theme; // 'light' | 'dark'
  String language; // 'hi' | 'en'
  bool autoDriveBackup;
  int? driveLastBackup; // epoch millis of the last successful Drive backup

  AppSettings({
    this.theme = 'dark',
    this.language = 'hi',
    this.autoDriveBackup = true,
    this.driveLastBackup,
  });

  factory AppSettings.fromJson(Map<String, dynamic> json) => AppSettings(
        theme: json['theme'] as String? ?? 'dark',
        language: json['language'] as String? ?? 'hi',
        autoDriveBackup: json['autoDriveBackup'] as bool? ?? true,
        driveLastBackup: json['driveLastBackup'] as int?,
      );

  Map<String, dynamic> toJson() => {
        'theme': theme,
        'language': language,
        'autoDriveBackup': autoDriveBackup,
        'driveLastBackup': driveLastBackup,
      };
}
