/// Per worker-month metadata: opening balance carried in, and whether
/// this month has been "settled" (closed out) into a later month.
class MonthMeta {
  final double openingBalance;
  final bool settled;
  final String? settledInto; // "year-month" key this month's balance rolled into

  const MonthMeta({
    this.openingBalance = 0,
    this.settled = false,
    this.settledInto,
  });

  MonthMeta copyWith({
    double? openingBalance,
    bool? settled,
    String? settledInto,
  }) =>
      MonthMeta(
        openingBalance: openingBalance ?? this.openingBalance,
        settled: settled ?? this.settled,
        settledInto: settledInto ?? this.settledInto,
      );

  factory MonthMeta.fromJson(Map<String, dynamic> json) => MonthMeta(
        openingBalance: (json['openingBalance'] as num?)?.toDouble() ?? 0,
        settled: json['settled'] as bool? ?? false,
        settledInto: json['settledInto'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'openingBalance': openingBalance,
        'settled': settled,
        'settledInto': settledInto,
      };
}

/// Key format matches the web app: "<workerId>_<year>_<month>"
String monthMetaKey(String workerId, int year, int month) =>
    '${workerId}_${year}_$month';
