class Worker {
  final String id;
  String name;
  String? contact; // legacy alias for phone, kept for compatibility
  String? phone;
  String? bio;
  double rate; // default rate per stitch
  String? photoUrl; // local file path or remote url
  String? shareEmail;
  bool shareOn;
  int sortIndex;

  Worker({
    required this.id,
    required this.name,
    this.contact,
    this.phone,
    this.bio,
    this.rate = 0,
    this.photoUrl,
    this.shareEmail,
    this.shareOn = false,
    this.sortIndex = 0,
  });

  factory Worker.fromJson(Map<String, dynamic> json) => Worker(
        id: json['id'] as String,
        name: json['name'] as String? ?? '',
        contact: json['contact'] as String?,
        phone: json['phone'] as String?,
        bio: json['bio'] as String?,
        rate: (json['rate'] as num?)?.toDouble() ?? 0,
        photoUrl: json['photoUrl'] as String?,
        shareEmail: json['shareEmail'] as String?,
        shareOn: json['shareOn'] as bool? ?? false,
        sortIndex: json['sortIndex'] as int? ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'contact': contact,
        'phone': phone,
        'bio': bio,
        'rate': rate,
        'photoUrl': photoUrl,
        'shareEmail': shareEmail,
        'shareOn': shareOn,
        'sortIndex': sortIndex,
      };
}
