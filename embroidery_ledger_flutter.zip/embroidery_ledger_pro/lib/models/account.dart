import 'khata_transaction.dart';

enum AccountType { customer, supplier }

extension AccountTypeX on AccountType {
  String get value => this == AccountType.customer ? 'customer' : 'supplier';

  static AccountType fromValue(String? v) =>
      v == 'customer' ? AccountType.customer : AccountType.supplier;
}

/// A customer or supplier "khata" (ledger account).
class Account {
  final String id;
  String name;
  String? contact;
  AccountType type;
  List<KhataTransaction> transactions;

  Account({
    required this.id,
    required this.name,
    this.contact,
    required this.type,
    List<KhataTransaction>? transactions,
  }) : transactions = transactions ?? [];

  bool get isCustomer => type == AccountType.customer;

  /// Positive balance = udhar/baki owed. Mirrors getKhataBalance() in the web app:
  /// unpaid bills add to balance; payments (and paid bills) subtract from it.
  double get balance {
    double udhar = 0;
    double paid = 0;
    for (final t in transactions) {
      if (t.txType == TxType.bill && t.billStatus == BillStatus.unpaid) {
        udhar += t.amount;
      }
      if (t.txType == TxType.payment ||
          (t.txType == TxType.bill && t.billStatus == BillStatus.paid)) {
        paid += t.amount;
      }
    }
    return udhar - paid;
  }

  factory Account.fromJson(Map<String, dynamic> json) => Account(
        id: json['id'] as String,
        name: json['name'] as String? ?? '',
        contact: json['contact'] as String?,
        type: AccountTypeX.fromValue(json['type'] as String?),
        transactions: (json['transactions'] as List<dynamic>? ?? [])
            .map((e) => KhataTransaction.fromJson(e as Map<String, dynamic>))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'contact': contact,
        'type': type.value,
        'transactions': transactions.map((e) => e.toJson()).toList(),
      };
}
