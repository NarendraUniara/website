enum PaymentType { advance, salary }

extension PaymentTypeX on PaymentType {
  String get value => this == PaymentType.advance ? 'advance' : 'salary';

  static PaymentType fromValue(String? v) =>
      v == 'advance' ? PaymentType.advance : PaymentType.salary;
}

/// A payment made to a worker (advance or salary), tied to a specific month.
class Payment {
  final String id;
  final String workerId;
  final int year;
  final int month;
  final PaymentType type;
  final double amount;
  final String date; // ISO date yyyy-MM-dd
  final String? note;
  final int createdAt;

  Payment({
    required this.id,
    required this.workerId,
    required this.year,
    required this.month,
    required this.type,
    required this.amount,
    required this.date,
    this.note,
    required this.createdAt,
  });

  factory Payment.fromJson(Map<String, dynamic> json) => Payment(
        id: json['id'] as String,
        workerId: json['workerId'] as String,
        year: json['year'] as int,
        month: json['month'] as int,
        type: PaymentTypeX.fromValue(json['type'] as String?),
        amount: (json['amount'] as num?)?.toDouble() ?? 0,
        date: json['date'] as String? ?? '',
        note: json['note'] as String?,
        createdAt: json['createdAt'] as int? ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'workerId': workerId,
        'year': year,
        'month': month,
        'type': type.value,
        'amount': amount,
        'date': date,
        'note': note,
        'createdAt': createdAt,
      };
}
