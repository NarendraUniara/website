enum CashEntryType { income, expense }

extension CashEntryTypeX on CashEntryType {
  String get value => this == CashEntryType.income ? 'income' : 'expense';

  static CashEntryType fromValue(String? v) =>
      v == 'income' ? CashEntryType.income : CashEntryType.expense;
}

/// A single cash-book entry (income or expense), independent of workers/khata.
class CashEntry {
  final String id;
  final CashEntryType type;
  final String date; // ISO date yyyy-MM-dd
  final String time;
  final double amount;
  final String? note;
  final String? category;
  final int createdAt;

  CashEntry({
    required this.id,
    required this.type,
    required this.date,
    required this.time,
    required this.amount,
    this.note,
    this.category,
    required this.createdAt,
  });

  factory CashEntry.fromJson(Map<String, dynamic> json) => CashEntry(
        id: json['id'] as String,
        type: CashEntryTypeX.fromValue(json['type'] as String?),
        date: json['date'] as String? ?? '',
        time: json['time'] as String? ?? '',
        amount: (json['amount'] as num?)?.toDouble() ?? 0,
        note: json['note'] as String?,
        category: json['category'] as String?,
        createdAt: json['createdAt'] as int? ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.value,
        'date': date,
        'time': time,
        'amount': amount,
        'note': note,
        'category': category,
        'createdAt': createdAt,
      };
}
