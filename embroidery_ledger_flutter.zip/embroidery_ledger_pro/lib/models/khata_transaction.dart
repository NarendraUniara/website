enum TxType { bill, payment }

extension TxTypeX on TxType {
  String get value => this == TxType.bill ? 'bill' : 'payment';

  static TxType fromValue(String? v) => v == 'bill' ? TxType.bill : TxType.payment;
}

enum BillStatus { paid, unpaid }

extension BillStatusX on BillStatus {
  String get value => this == BillStatus.paid ? 'paid' : 'unpaid';

  static BillStatus? fromValue(String? v) {
    if (v == 'paid') return BillStatus.paid;
    if (v == 'unpaid') return BillStatus.unpaid;
    return null;
  }
}

enum PayMode { cash, online }

extension PayModeX on PayMode {
  String get value => this == PayMode.cash ? 'cash' : 'online';

  static PayMode? fromValue(String? v) {
    if (v == 'cash') return PayMode.cash;
    if (v == 'online') return PayMode.online;
    return null;
  }
}

/// A single transaction (bill given/received, or payment made/received)
/// under a customer or supplier account.
class KhataTransaction {
  final String id;
  final TxType txType;
  final BillStatus? billStatus; // relevant when txType == bill
  final PayMode? payMode; // relevant when txType == payment
  final double amount;
  final String date; // ISO date yyyy-MM-dd
  final String time;
  final String? note;
  final String? category;
  final int createdAt;

  KhataTransaction({
    required this.id,
    required this.txType,
    this.billStatus,
    this.payMode,
    required this.amount,
    required this.date,
    required this.time,
    this.note,
    this.category,
    required this.createdAt,
  });

  factory KhataTransaction.fromJson(Map<String, dynamic> json) => KhataTransaction(
        id: json['id'] as String,
        txType: TxTypeX.fromValue(json['txType'] as String?),
        billStatus: BillStatusX.fromValue(json['billStatus'] as String?),
        payMode: PayModeX.fromValue(json['payMode'] as String?),
        amount: (json['amount'] as num?)?.toDouble() ?? 0,
        date: json['date'] as String? ?? '',
        time: json['time'] as String? ?? '',
        note: json['note'] as String?,
        category: json['category'] as String?,
        createdAt: json['createdAt'] as int? ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'txType': txType.value,
        'billStatus': billStatus?.value,
        'payMode': payMode?.value,
        'amount': amount,
        'date': date,
        'time': time,
        'note': note,
        'category': category,
        'createdAt': createdAt,
      };
}
