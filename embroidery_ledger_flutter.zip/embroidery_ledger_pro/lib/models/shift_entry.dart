/// A single day's work entry for a worker within a given month.
class ShiftEntry {
  final String id;
  final String workerId;
  final int year;
  final int month; // 1-12
  final int day; // 1-31
  final bool absent;
  final String shift; // one of ShiftType ids: morning/afternoon/evening/full/fullnight/halfnight/halfday
  final double stitches;
  final double rate;
  final double hours;
  final double advance;
  final int createdAt;

  ShiftEntry({
    required this.id,
    required this.workerId,
    required this.year,
    required this.month,
    required this.day,
    this.absent = false,
    this.shift = 'full',
    this.stitches = 0,
    this.rate = 0,
    this.hours = 0,
    this.advance = 0,
    required this.createdAt,
  });

  double get earned => absent ? 0 : stitches * rate;

  factory ShiftEntry.fromJson(Map<String, dynamic> json) => ShiftEntry(
        id: json['id'] as String,
        workerId: json['workerId'] as String,
        year: json['year'] as int,
        month: json['month'] as int,
        day: json['day'] as int,
        absent: json['absent'] as bool? ?? false,
        shift: json['shift'] as String? ?? 'full',
        stitches: (json['stitches'] as num?)?.toDouble() ?? 0,
        rate: (json['rate'] as num?)?.toDouble() ?? 0,
        hours: (json['hours'] as num?)?.toDouble() ?? 0,
        advance: (json['advance'] as num?)?.toDouble() ?? 0,
        createdAt: json['createdAt'] as int? ?? 0,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'workerId': workerId,
        'year': year,
        'month': month,
        'day': day,
        'absent': absent,
        'shift': shift,
        'stitches': stitches,
        'rate': rate,
        'hours': hours,
        'advance': advance,
        'createdAt': createdAt,
      };
}

/// Mirrors the SHIFTS list in the web app: id, Hindi label, English label, emoji icon.
class ShiftType {
  final String id;
  final String label; // Hindi
  final String en;
  final String icon; // emoji

  const ShiftType(this.id, this.label, this.en, this.icon);

  static const List<ShiftType> all = [
    ShiftType('morning', 'Subah', 'Morning', '🌅'),
    ShiftType('afternoon', 'Dopahar', 'Afternoon', '☀️'),
    ShiftType('evening', 'Shaam', 'Evening', '🌇'),
    ShiftType('full', 'Din Bhar', 'Full Day', '🕐'),
    ShiftType('fullnight', 'Puri Raat', 'Full Night', '🌙'),
    ShiftType('halfnight', 'Aadhi Raat', 'Half Night', '🌘'),
    ShiftType('halfday', 'Aadha Din', 'Half Day', '🌤️'),
  ];

  static ShiftType of(String? id) =>
      all.firstWhere((s) => s.id == id, orElse: () => all[3]);
}
