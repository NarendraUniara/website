import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/worker.dart';
import '../models/shift_entry.dart';
import '../models/payment.dart';
import '../models/month_meta.dart';
import '../models/account.dart';
import '../models/cash_entry.dart';
import '../models/app_settings.dart';
import '../services/local_storage_service.dart';
import '../services/firestore_service.dart';

const _uuid = Uuid();
String newId() => _uuid.v4();

const List<String> defaultCategories = ['Bill', 'Rent', 'Lugadi Safai', 'Worker Payment'];
const List<String> defaultIncomeCategories = ['Sale', 'Advance Wapsi', 'Customer Payment', 'Other'];
const List<String> defaultKhataCategories = ['Maal', 'Dhaaga', 'Transport', 'Advance', 'Other'];

/// Computed stats for a single worker-month, mirroring getMonthStats() in the web app.
class MonthStats {
  final List<ShiftEntry> entries;
  final int workingDays;
  final int absentDays;
  final double totalStitches;
  final double totalHours;
  final double totalEarned;
  final double entryAdvance;
  final double paymentAdvance;
  final double totalAdvance;
  final double salaryPaid;
  final double totalPaid;
  final double opening;
  final double baki;
  final bool settled;
  final String? settledInto;

  MonthStats({
    required this.entries,
    required this.workingDays,
    required this.absentDays,
    required this.totalStitches,
    required this.totalHours,
    required this.totalEarned,
    required this.entryAdvance,
    required this.paymentAdvance,
    required this.totalAdvance,
    required this.salaryPaid,
    required this.totalPaid,
    required this.opening,
    required this.baki,
    required this.settled,
    required this.settledInto,
  });
}

class WorkerAllTimeStats {
  final int workingDays;
  final double totalEarned;
  final double totalAdvance;
  final double salaryPaid;
  final double outstanding;
  final int monthsCount;

  WorkerAllTimeStats({
    required this.workingDays,
    required this.totalEarned,
    required this.totalAdvance,
    required this.salaryPaid,
    required this.outstanding,
    required this.monthsCount,
  });
}

class AppState extends ChangeNotifier {
  final LocalStorageService _local = LocalStorageService();
  final FirestoreService _firestore = FirestoreService();

  List<Worker> workers = [];
  List<ShiftEntry> entries = [];
  Map<String, MonthMeta> monthMeta = {};
  List<Payment> payments = [];
  List<CashEntry> incomeExpense = [];
  List<Account> accounts = [];

  List<String> customCategories = [];
  List<String> customKhataCategories = [];
  List<String> customIncomeCategories = [];
  List<String> hiddenCategories = [];
  List<String> hiddenIncomeCategories = [];

  AppSettings settings = AppSettings();

  Timer? _saveDebounce;

  // ---------------- Load / Save ----------------

  Future<void> load() async {
    final data = await _local.loadState();
    if (data != null) {
      _applyJson(data);
    }
    notifyListeners();
  }

  void _applyJson(Map<String, dynamic> data) {
    workers = (data['workers'] as List<dynamic>? ?? [])
        .map((e) => Worker.fromJson(e as Map<String, dynamic>))
        .toList();
    entries = (data['entries'] as List<dynamic>? ?? [])
        .map((e) => ShiftEntry.fromJson(e as Map<String, dynamic>))
        .toList();
    monthMeta = (data['monthMeta'] as Map<String, dynamic>? ?? {}).map(
      (k, v) => MapEntry(k, MonthMeta.fromJson(v as Map<String, dynamic>)),
    );
    payments = (data['payments'] as List<dynamic>? ?? [])
        .map((e) => Payment.fromJson(e as Map<String, dynamic>))
        .toList();
    incomeExpense = (data['incomeExpense'] as List<dynamic>? ?? [])
        .map((e) => CashEntry.fromJson(e as Map<String, dynamic>))
        .toList();
    accounts = (data['accounts'] as List<dynamic>? ?? [])
        .map((e) => Account.fromJson(e as Map<String, dynamic>))
        .toList();
    customCategories = List<String>.from(data['customCategories'] as List? ?? []);
    customKhataCategories = List<String>.from(data['customKhataCategories'] as List? ?? []);
    customIncomeCategories = List<String>.from(data['customIncomeCategories'] as List? ?? []);
    hiddenCategories = List<String>.from(data['hiddenCategories'] as List? ?? []);
    hiddenIncomeCategories = List<String>.from(data['hiddenIncomeCategories'] as List? ?? []);
    if (data['settings'] != null) {
      settings = AppSettings.fromJson(data['settings'] as Map<String, dynamic>);
    }
  }

  /// Mirrors the restoreFile onchange handler: overwrites current state with
  /// a parsed backup file, but keeps each worker's photo exactly as it is on
  /// this device (photos are never included in — or restored from — backups).
  void restoreFromBackup(Map<String, dynamic> data) {
    final photoMap = {for (final w in workers) w.id: w.photoUrl};
    _applyJson(data);
    for (final w in workers) {
      if (w.photoUrl == null && photoMap.containsKey(w.id)) {
        w.photoUrl = photoMap[w.id];
      }
    }
    scheduleSave();
  }

  Map<String, dynamic> toJson() => {
        'workers': workers.map((e) => e.toJson()).toList(),
        'entries': entries.map((e) => e.toJson()).toList(),
        'monthMeta': monthMeta.map((k, v) => MapEntry(k, v.toJson())),
        'payments': payments.map((e) => e.toJson()).toList(),
        'incomeExpense': incomeExpense.map((e) => e.toJson()).toList(),
        'accounts': accounts.map((e) => e.toJson()).toList(),
        'customCategories': customCategories,
        'customKhataCategories': customKhataCategories,
        'customIncomeCategories': customIncomeCategories,
        'hiddenCategories': hiddenCategories,
        'hiddenIncomeCategories': hiddenIncomeCategories,
        'settings': settings.toJson(),
      };

  /// Mirrors exportBackup(): a plain-JSON snapshot with each worker's local
  /// photo stripped out (photos stay on-device and are never backed up).
  Map<String, dynamic> toBackupJson() {
    final json = toJson();
    json['workers'] = workers.map((w) {
      final wj = w.toJson();
      wj.remove('photoUrl');
      return wj;
    }).toList();
    return json;
  }

  /// Set from main.dart's AuthService.authStateChanges listener — mirrors
  /// the web app's `currentUser` check inside scheduleSave().
  String? signedInEmail;

  /// Debounced save — mirrors scheduleSave() in the web app: saves locally
  /// immediately-ish, and (if signed in + sharing is on) pushes to Firestore.
  void scheduleSave() {
    _saveDebounce?.cancel();
    _saveDebounce = Timer(const Duration(milliseconds: 400), () async {
      await _local.saveState(toJson());
      if (signedInEmail != null) {
        for (final w in workers.where((w) => w.shareOn && w.shareEmail != null)) {
          await _firestore.syncWorker(w, entries, payments, monthMeta);
        }
      }
    });
    notifyListeners();
  }

  /// Mirrors resyncIfShared(wid): pushes just one worker's data to Firestore
  /// right away (used right after editing a shared worker's profile/rate).
  Future<void> resyncIfShared(String wid) async {
    if (signedInEmail == null) return;
    final w = getWorker(wid);
    if (w == null || !w.shareOn || w.shareEmail == null) return;
    await _firestore.syncWorker(w, entries, payments, monthMeta);
  }

  /// Mirrors toggleWorkerShare(wid): turns sharing on/off for a worker.
  void toggleWorkerShare(String wid, bool on) {
    final w = getWorker(wid);
    if (w == null) return;
    w.shareOn = on;
    scheduleSave();
    if (on) resyncIfShared(wid);
  }

  /// Mirrors saveWorkerShareEmail(wid): sets which email a worker's hisab is shared to.
  void saveWorkerShareEmail(String wid, String email) {
    final w = getWorker(wid);
    if (w == null) return;
    w.shareEmail = email.trim().isEmpty ? null : email.trim();
    scheduleSave();
    resyncIfShared(wid);
  }

  // ---------------- Categories ----------------

  List<String> getCategories() =>
      defaultCategories.concatCustom(customCategories).where((c) => !hiddenCategories.contains(c)).toList();

  List<String> getIncomeCategories() => defaultIncomeCategories
      .concatCustom(customIncomeCategories)
      .where((c) => !hiddenIncomeCategories.contains(c))
      .toList();

  List<String> getKhataCategories() => defaultKhataCategories.concatCustom(customKhataCategories);

  // ---------------- Workers ----------------

  Worker? getWorker(String id) {
    for (final w in workers) {
      if (w.id == id) return w;
    }
    return null;
  }

  void addWorker(Worker w) {
    workers.add(w);
    scheduleSave();
  }

  void reorderWorkers(List<Worker> newOrder) {
    workers = newOrder;
    scheduleSave();
  }

  void deleteWorker(String wid) {
    workers.removeWhere((w) => w.id == wid);
    entries.removeWhere((e) => e.workerId == wid);
    payments.removeWhere((p) => p.workerId == wid);
    scheduleSave();
  }

  // ---------------- Month meta ----------------

  MonthMeta getMonthMeta(String wid, int y, int m) =>
      monthMeta[monthMetaKey(wid, y, m)] ?? const MonthMeta();

  void setMonthMeta(String wid, int y, int m, MonthMeta patch) {
    final k = monthMetaKey(wid, y, m);
    monthMeta[k] = patch;
  }

  void unlockMonthsThatSettledInto(String wid, int y, int m) {
    final target = '$y-$m';
    monthMeta.forEach((k, meta) {
      if (!k.startsWith('${wid}_')) return;
      if (meta.settled && meta.settledInto == target) {
        monthMeta[k] = meta.copyWith(settled: false, settledInto: null);
      }
    });
  }

  // ---------------- Start next month (carry-forward) ----------------

  /// Mirrors openAddNextMonthModal(): figures out which month comes next
  /// for this worker (or the current month if they have none yet), plus
  /// the previous month's outstanding baki (if any) so the UI can offer
  /// a carry-forward-vs-settle-now choice.
  ({int year, int month, ({int year, int month})? prev, double prevBaki, bool alreadyExists}) nextMonthTarget(
      String wid) {
    final months = getWorkerMonths(wid);
    ({int year, int month})? prev;
    ({int year, int month}) target;
    if (months.isEmpty) {
      final now = DateTime.now();
      target = (year: now.year, month: now.month);
    } else {
      prev = months.first;
      var m = prev.month + 1;
      var y = prev.year;
      if (m > 12) {
        m = 1;
        y++;
      }
      target = (year: y, month: m);
    }
    final alreadyExists = months.any((mo) => mo.year == target.year && mo.month == target.month);
    final prevBaki = prev != null ? getMonthStats(wid, prev.year, prev.month).baki : 0.0;
    return (year: target.year, month: target.month, prev: prev, prevBaki: prevBaki, alreadyExists: alreadyExists);
  }

  /// Mirrors confirmAddNextMonth(): starts the target month for this worker.
  /// If [settleNow] is true and the previous month has a positive baki, a
  /// salary payment is recorded for the full baki and the previous month is
  /// closed with nothing carried forward. Otherwise any non-zero baki
  /// (positive or negative) is carried into the new month's opening balance.
  void startNextMonth(String wid, int year, int month, ({int year, int month})? prev, bool settleNow) {
    double opening = 0;
    if (prev != null) {
      final pstats = getMonthStats(wid, prev.year, prev.month);
      if (pstats.baki > 0.5 && settleNow) {
        payments.add(Payment(
          id: newId(),
          workerId: wid,
          year: prev.year,
          month: prev.month,
          type: PaymentType.salary,
          amount: pstats.baki,
          date: _todayIso(),
          note: 'Settlement',
          createdAt: DateTime.now().millisecondsSinceEpoch,
        ));
        setMonthMeta(wid, prev.year, prev.month, const MonthMeta(settled: true));
        opening = 0;
      } else if (pstats.baki.abs() > 0.5) {
        opening = pstats.baki;
        setMonthMeta(wid, prev.year, prev.month, MonthMeta(settled: true, settledInto: '$year-$month'));
      } else {
        setMonthMeta(wid, prev.year, prev.month, const MonthMeta(settled: true));
      }
    }
    setMonthMeta(wid, year, month, MonthMeta(openingBalance: opening, settled: false));
    scheduleSave();
  }

  String _todayIso() {
    final d = DateTime.now();
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  /// Mirrors checkSharedUpdate(email): fetches the raw shared-worker doc
  /// (if any) for the currently signed-in email — someone else's worker
  /// that they've shared with this account, read-only.
  Future<Map<String, dynamic>?> fetchSharedData() async {
    if (signedInEmail == null) return null;
    return _firestore.fetchSharedForEmail(signedInEmail!);
  }

  // ---------------- Stats ----------------

  List<({int year, int month})> getWorkerMonths(String wid) {
    final map = <String, ({int year, int month})>{};
    for (final e in entries.where((e) => e.workerId == wid)) {
      map['${e.year}-${e.month}'] = (year: e.year, month: e.month);
    }
    for (final p in payments.where((p) => p.workerId == wid)) {
      map['${p.year}-${p.month}'] = (year: p.year, month: p.month);
    }
    for (final k in monthMeta.keys.where((k) => k.startsWith('${wid}_'))) {
      final parts = k.split('_');
      final y = int.parse(parts[1]);
      final m = int.parse(parts[2]);
      map['$y-$m'] = (year: y, month: m);
    }
    final list = map.values.toList()
      ..sort((a, b) {
        final byYear = b.year.compareTo(a.year);
        return byYear != 0 ? byYear : b.month.compareTo(a.month);
      });
    return list;
  }

  MonthStats getMonthStats(String wid, int y, int m, [Set<String>? visited]) {
    final monthEntries = entries
        .where((e) => e.workerId == wid && e.year == y && e.month == m)
        .toList()
      ..sort((a, b) => a.day.compareTo(b.day));
    final meta = getMonthMeta(wid, y, m);
    final workingDays = monthEntries.where((e) => !e.absent).length;
    final absentDays = monthEntries.where((e) => e.absent).length;
    final totalStitches = monthEntries.fold<double>(0, (s, e) => s + (e.absent ? 0 : e.stitches));
    final totalHours = monthEntries.fold<double>(0, (s, e) => s + (e.absent ? 0 : e.hours));
    final totalEarned = monthEntries.fold<double>(0, (s, e) => s + e.earned);
    final entryAdvance = monthEntries.fold<double>(0, (s, e) => s + e.advance);

    final monthPayments = payments.where((p) => p.workerId == wid && p.year == y && p.month == m);
    final paymentAdvance = monthPayments
        .where((p) => p.type == PaymentType.advance)
        .fold<double>(0, (s, p) => s + p.amount);
    final salaryPaid = monthPayments
        .where((p) => p.type == PaymentType.salary)
        .fold<double>(0, (s, p) => s + p.amount);
    final totalAdvance = entryAdvance + paymentAdvance;

    final visitedSet = visited ?? <String>{};
    final key = '$y-$m';
    visitedSet.add(key);

    double opening = meta.openingBalance;
    String? srcKey;
    for (final k in monthMeta.keys) {
      if (!k.startsWith('${wid}_')) continue;
      final mm = monthMeta[k];
      if (mm != null && mm.settled && mm.settledInto == key) {
        final parts = k.split('_');
        final label = '${parts[1]}-${parts[2]}';
        if (!visitedSet.contains(label)) {
          srcKey = k;
          break;
        }
      }
    }
    if (srcKey != null) {
      final parts = srcKey.split('_');
      final sy = int.parse(parts[1]);
      final sm = int.parse(parts[2]);
      final srcStats = getMonthStats(wid, sy, sm, visitedSet);
      opening = srcStats.baki;
    }

    final totalPaid = totalAdvance + salaryPaid;
    final baki = opening + totalEarned - totalAdvance - salaryPaid;

    return MonthStats(
      entries: monthEntries,
      workingDays: workingDays,
      absentDays: absentDays,
      totalStitches: totalStitches,
      totalHours: totalHours,
      totalEarned: totalEarned,
      entryAdvance: entryAdvance,
      paymentAdvance: paymentAdvance,
      totalAdvance: totalAdvance,
      salaryPaid: salaryPaid,
      totalPaid: totalPaid,
      opening: opening,
      baki: baki,
      settled: meta.settled,
      settledInto: meta.settledInto,
    );
  }

  WorkerAllTimeStats getWorkerAllTimeStats(String wid) {
    final months = getWorkerMonths(wid);
    int workingDays = 0;
    double totalEarned = 0, totalAdvance = 0, salaryPaid = 0, outstanding = 0;
    for (final mo in months) {
      final s = getMonthStats(wid, mo.year, mo.month);
      workingDays += s.workingDays;
      totalEarned += s.totalEarned;
      salaryPaid += s.salaryPaid;
      if (!s.settled) {
        totalAdvance += s.totalAdvance;
        outstanding += s.baki;
      }
    }
    return WorkerAllTimeStats(
      workingDays: workingDays,
      totalEarned: totalEarned,
      totalAdvance: totalAdvance,
      salaryPaid: salaryPaid,
      outstanding: outstanding,
      monthsCount: months.length,
    );
  }

  // ---------------- Khata / Accounts ----------------

  void addAccount(Account a) {
    accounts.add(a);
    scheduleSave();
  }

  void deleteAccount(String aid) {
    accounts.removeWhere((a) => a.id == aid);
    scheduleSave();
  }

  void addTxCategory(String name) {
    if (!getKhataCategories().any((c) => c.toLowerCase() == name.toLowerCase())) {
      customKhataCategories.add(name);
      scheduleSave();
    }
  }

  /// Mirrors addCategoryPrompt() for the cash book (income/expense) categories.
  void addCashCategory(String name, bool isIncome) {
    final list = isIncome ? customIncomeCategories : customCategories;
    final existing = isIncome ? getIncomeCategories() : getCategories();
    if (!existing.any((c) => c.toLowerCase() == name.toLowerCase())) {
      list.add(name);
      scheduleSave();
    }
  }
}

extension _ConcatCustom on List<String> {
  List<String> concatCustom(List<String> custom) => [...this, ...custom];
}
