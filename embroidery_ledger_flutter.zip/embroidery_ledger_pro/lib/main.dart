import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';
import 'state/app_state.dart';
import 'services/auth_service.dart';
import 'utils/app_theme.dart';
import 'screens/root_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  final appState = AppState();
  await appState.load();

  final authService = AuthService();
  authService.authStateChanges.listen((user) {
    appState.signedInEmail = user?.email;
  });

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: appState),
        Provider.value(value: authService),
      ],
      child: const EmbroideryLedgerApp(),
    ),
  );
}

class EmbroideryLedgerApp extends StatelessWidget {
  const EmbroideryLedgerApp({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final isDark = appState.settings.theme == 'dark';
    final colors = isDark ? AppColors.dark : AppColors.light;

    return MaterialApp(
      title: 'Embroidery Ledger',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(colors, isDark ? Brightness.dark : Brightness.light),
      builder: (context, child) => AppColorsProvider(
        colors: colors,
        child: child!,
      ),
      home: const RootShell(),
    );
  }
}
