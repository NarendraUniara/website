package com.embroideryledger.pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
